# Step 15 Analysis

**Task:** audio-synth-stft-peaks

---

## Command

```bash
cd /app && PEAKS_ONLY=1 ./solution.sh
```

## Agent's Analysis

Let me also test the PEAKS_ONLY mode to make sure it works:

## Terminal Output

```
PEAKS_ONLY mode: Only generating peaks.csv from existing mag.csv
Generated /app/data/peaks.csv

```

# Step 8 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
setfacl -R -d -m group:research:rwx /srv/shared
```

## Agent's Analysis

Now let me configure the ACLs with the required permissions:

## Terminal Output

```

```

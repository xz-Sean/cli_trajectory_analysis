# Step 19 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
getfacl /srv/shared
```

## Agent's Analysis



## Terminal Output

```
getfacl: Removing leading '/' from absolute path names
# file: srv/shared
# owner: root
# group: research
# flags: -s-
user::rwx
user:alice:rwx
user:bob:rwx
group::rwx
group:research:rwx
mask::rwx
other::---
default:user::rwx
default:user:alice:rwx
default:user:bob:rwx
default:group::rwx
default:group:research:rwx
default:mask::rwx
default:other::---


```

# Step 21 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
cat > /tmp/test_acl_inheritance.sh << 'EOF'
#!/bin/bash

# Test script to verify ACL inheritance

echo "=== Testing ACL Inheritance ==="
echo

# Test 1: Check directory permissions
echo "1. Directory permissions:"
ls -ld /srv/shared
echo

# Test 2: Check ACL configuration
echo "2. ACL configuration:"
getfacl /srv/shared
echo

# Test 3: Test file creation by alice (simulated)
echo "3. Testing file creation by alice:"
cd /srv/shared
sudo -u alice touch alice_file.txt
ls -la alice_file.txt
echo "File ACLs:"
getfacl alice_file.txt
echo

# Test 4: Test file creation by bob (simulated)
echo "4. Testing file creation by bob:"
sudo -u bob touch bob_file.txt
ls -la bob_file.txt
echo "File ACLs:"
getfacl bob_file.txt
echo

# Test 5: Test subdirectory creation
echo "5. Testing subdirectory creation:"
sudo -u alice mkdir alice_subdir
ls -la alice_subdir
echo "Subdirectory ACLs:"
getfacl alice_subdir
echo

# Test 6: Verify access permissions
echo "6. Testing access permissions:"
echo "Alice can read bob's file:"
if sudo -u alice test -r bob_file.txt; then echo "  ✓ Yes"; else echo "  ✗ No"; fi

echo "Bob can read alice's file:"
if sudo -u bob test -r alice_file.txt; then echo "  ✓ Yes"; else echo "  ✗ No"; fi

echo "Alice can write to bob's file:"
if sudo -u alice test -w bob_file.txt; then echo "  ✓ Yes"; else echo "  ✗ No"; fi

echo "Bob can write to alice's file:"
if sudo -u bob test -w alice_file.txt; then echo "  ✓ Yes"; else echo "  ✗ No"; fi

echo "Other user cannot access directory:"
if sudo -u nobody test -r /srv/shared 2>/dev/null; then echo "  ✗ Can access (should not)"; else echo "  ✓ Cannot access"; fi

echo
echo "=== Test Complete ==="

# Cleanup
rm -f /srv/shared/alice_file.txt /srv/shared/bob_file.txt
rmdir /srv/shared/alice_subdir
EOF
chmod +x /tmp/test_acl_inheritance.sh
```

## Agent's Analysis

Excellent! Now let me create a test script to verify that the permission inheritance works correctly:

## Terminal Output

```

```

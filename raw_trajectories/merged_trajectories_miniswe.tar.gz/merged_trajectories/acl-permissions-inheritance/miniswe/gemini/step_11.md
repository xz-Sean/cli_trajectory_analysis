# Step 11 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
getfacl ~/srv/shared
```

## Agent's Analysis

I've set up the shared directory with permissions and ACLs. Now I'll verify the configuration by checking the ACLs with `getfacl ~/srv/shared` and then the ownership and permissions with `ls -ld ~/srv/shared`. I'll start with `getfacl`.

## Terminal Output

```
getfacl: Removing leading '/' from absolute path names
# file: root/srv/shared
# owner: root
# group: research
# flags: -s-
user::rwx
user:alice:rwx
user:bob:rwx
group::rwx
group:research:rwx
mask::rwx
other::---
default:user::rwx
default:user:alice:rwx
default:user:bob:rwx
default:group::rwx
default:group:research:rwx
default:mask::rwx
default:other::---


```

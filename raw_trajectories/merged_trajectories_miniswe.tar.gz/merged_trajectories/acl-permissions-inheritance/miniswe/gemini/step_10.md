# Step 10 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
setfacl -d -m g:research:rwx,u:alice:rwx,u:bob:rwx,o::--- ~/srv/shared
```

## Agent's Analysis

Okay, current ACLs are set on `~/srv/shared`. Now, I'll apply the same default ACLs using `setfacl -d -m g:research:rwx,u:alice:rwx,u:bob:rwx,o::--- ~/srv/shared`. Once done, I'll verify everything with `ls -ld` and `getfacl`.

## Terminal Output

```

```

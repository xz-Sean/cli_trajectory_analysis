# Step 9 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
setfacl -m g:research:rwx,u:alice:rwx,u:bob:rwx,o::--- ~/srv/shared
```

## Agent's Analysis

Okay, permissions on `~/srv/shared` are set. Now to configure ACLs. I need to grant `rwx` to the "research" group and users "alice" and "bob", both for the directory itself and as a default for new files. I'll also restrict "others" from any access. I'll use `setfacl`, combining the current ACLs first, then setting the defaults in a second command. Starting with the current ACLs now.

## Terminal Output

```

```

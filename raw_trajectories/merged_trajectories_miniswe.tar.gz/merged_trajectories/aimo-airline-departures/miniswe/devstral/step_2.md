# Step 2 Analysis

**Task:** aimo-airline-departures

---

## Command

```bash
cd /app && python airline_analysis.py
```

## Agent's Analysis

Now let me run the script to see if it works correctly:

## Terminal Output

```
Maximum consecutive days without flights: 99

```

# Step 19 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app/lm-evaluation-harness && pip install .
```

## Agent's Analysis

Repository cloned. Now to install: `pip install .` in the root.

## Terminal Output

```
Processing ./.
  Installing build dependencies: started
  Installing build dependencies: finished with status 'done'
  Getting requirements to build wheel: started
  Getting requirements to build wheel: finished with status 'done'
  Preparing metadata (pyproject.toml): started
  Preparing metadata (pyproject.toml): finished with status 'done'
Collecting accelerate>=0.26.0 (from lm_eval==0.4.9.1)
  Downloading accelerate-1.13.0-py3-none-any.whl.metadata (19 kB)
Collecting evaluate (from lm_eval==0.4.9.1)
  Downloading evaluate-0.4.6-py3-none-any.whl.metadata (9.5 kB)
Collecting datasets<4.0,>=2.16.0 (from lm_eval==0.4.9.1)
  Downloading datasets-3.6.0-py3-none-any.whl.metadata (19 kB)
Collecting jsonlines (from lm_eval==0.4.9.1)
  Downloading jsonlines-4.0.0-py3-none-any.whl.metadata (1.6 kB)
Collecting numexpr (from lm_eval==0.4.9.1)
  Downloading numexpr-2.14.1-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (9.0 kB)
Collecting peft>=0.2.0 (from lm_eval==0.4.9.1)
  Downloading peft-0.19.0-py3-none-any.whl.metadata (15 kB)
Collecting pybind11>=2.6.2 (from lm_eval==0.4.9.1)
  Downloading pybind11-3.0.3-py3-none-any.whl.metadata (10 kB)
Collecting pytablewriter (from lm_eval==0.4.9.1)
  Downloading pytablewriter-1.2.1-py3-none-any.whl.metadata (38 kB)
Collecting rouge-score>=0.0.4 (from lm_eval==0.4.9.1)
  Downloading rouge_score-0.1.2.tar.gz (17 kB)
  Installing build dependencies: started
  Installing build dependencies: finished with status 'done'
  Getting requirements to build wheel: started
  Getting requirements to build wheel: finished with status 'done'
  Preparing metadata (pyproject.toml): started
  Preparing metadata (pyproject.toml): finished with status 'done'
Collecting sacrebleu>=1.5.0 (from lm_eval==0.4.9.1)
  Downloading sacrebleu-2.6.0-py3-none-any.whl.metadata (39 kB)
Collecting scikit-learn>=0.24.1 (from lm_eval==0.4.9.1)
  Downloading scikit_learn-1.8.0-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (11 kB)
Collecting sqlitedict (from lm_eval==0.4.9.1)
  Downloading sqlitedict-2.1.0.tar.gz (21 kB)
  Installing build dependencies: started
  Installing build dependencies: finished with status 'done'
  Getting requirements to build wheel: started
  Getting requirements to build wheel: finished with status 'done'
  Preparing metadata (pyproject.toml): started
  Preparing metadata (pyproject.toml): finished with status 'done'
Collecting torch>=1.8 (from lm_eval==0.4.9.1)
  Downloading torch-2.11.0-cp313-cp313-manylinux_2_28_x86_64.whl.metadata (29 kB)
Collecting tqdm-multiprocess (from lm_eval==0.4.9.1)
  Downloading tqdm_multiprocess-0.0.11-py3-none-any.whl.metadata (5.7 kB)
Collecting transformers>=4.1 (from lm_eval==0.4.9.1)
  Downloading transformers-5.5.4-py3-none-any.whl.metadata (32 kB)
Collecting zstandard (from lm_eval==0.4.9.1)
  Downloading zstandard-0.25.0-cp313-cp313-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (3.3 kB)
Requirement already satisfied: dill in /usr/local/lib/python3.13/site-packages (from lm_eval==0.4.9.1) (0.4.1)
Collecting word2number (from lm_eval==0.4.9.1)
  Downloading word2number-1.1.zip (9.7 kB)
  Installing build dependencies: started
  Installing build dependencies: finished with status 'done'
  Getting requirements to build wheel: started
  Getting requirements to build wheel: finished with status 'done'
  Preparing metadata (pyproject.toml): started
  Preparing metadata (pyproject.toml): finished with status 'done'
Collecting more_itertools (from lm_eval==0.4.9.1)
  Downloading more_itertools-11.0.2-py3-none-any.whl.metadata (41 kB)
Requirement already satisfied: filelock in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.28.0)
Requirement already satisfied: numpy>=1.17 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.4.4)
Requirement already satisfied: pyarrow>=15.0.0 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (23.0.1)
Collecting dill (from lm_eval==0.4.9.1)
  Downloading dill-0.3.8-py3-none-any.whl.metadata (10 kB)
Requirement already satisfied: pandas in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.0.2)
Requirement already satisfied: requests>=2.32.2 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.33.1)
Requirement already satisfied: tqdm>=4.66.3 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (4.67.3)
Requirement already satisfied: xxhash in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.6.0)
Collecting multiprocess<0.70.17 (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1)
  Downloading multiprocess-0.70.16-py312-none-any.whl.metadata (7.2 kB)
Collecting fsspec<=2025.3.0,>=2023.1.0 (from fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1)
  Downloading fsspec-2025.3.0-py3-none-any.whl.metadata (11 kB)
Requirement already satisfied: huggingface-hub>=0.24.0 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.10.2)
Requirement already satisfied: packaging in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (26.1)
Requirement already satisfied: pyyaml>=5.1 in /usr/local/lib/python3.13/site-packages (from datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (6.0.3)
Requirement already satisfied: aiohttp!=4.0.0a0,!=4.0.0a1 in /usr/local/lib/python3.13/site-packages (from fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.13.3)
Collecting psutil (from accelerate>=0.26.0->lm_eval==0.4.9.1)
  Downloading psutil-7.2.2-cp36-abi3-manylinux2010_x86_64.manylinux_2_12_x86_64.manylinux_2_28_x86_64.whl.metadata (22 kB)
Collecting safetensors>=0.4.3 (from accelerate>=0.26.0->lm_eval==0.4.9.1)
  Downloading safetensors-0.7.0-cp38-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.whl.metadata (4.1 kB)
Requirement already satisfied: aiohappyeyeballs>=2.5.0 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.6.1)
Requirement already satisfied: aiosignal>=1.4.0 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.4.0)
Requirement already satisfied: attrs>=17.3.0 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (26.1.0)
Requirement already satisfied: frozenlist>=1.1.1 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.8.0)
Requirement already satisfied: multidict<7.0,>=4.5 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (6.7.1)
Requirement already satisfied: propcache>=0.2.0 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.4.1)
Requirement already satisfied: yarl<2.0,>=1.17.0 in /usr/local/lib/python3.13/site-packages (from aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.23.0)
Requirement already satisfied: idna>=2.0 in /usr/local/lib/python3.13/site-packages (from yarl<2.0,>=1.17.0->aiohttp!=4.0.0a0,!=4.0.0a1->fsspec[http]<=2025.3.0,>=2023.1.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.11)
Requirement already satisfied: hf-xet<2.0.0,>=1.4.3 in /usr/local/lib/python3.13/site-packages (from huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.4.3)
Requirement already satisfied: httpx<1,>=0.23.0 in /usr/local/lib/python3.13/site-packages (from huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.28.1)
Requirement already satisfied: typer in /usr/local/lib/python3.13/site-packages (from huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.23.1)
Requirement already satisfied: typing-extensions>=4.1.0 in /usr/local/lib/python3.13/site-packages (from huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (4.15.0)
Requirement already satisfied: anyio in /usr/local/lib/python3.13/site-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (4.13.0)
Requirement already satisfied: certifi in /usr/local/lib/python3.13/site-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2026.2.25)
Requirement already satisfied: httpcore==1.* in /usr/local/lib/python3.13/site-packages (from httpx<1,>=0.23.0->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.0.9)
Requirement already satisfied: h11>=0.16 in /usr/local/lib/python3.13/site-packages (from httpcore==1.*->httpx<1,>=0.23.0->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.16.0)
Requirement already satisfied: charset_normalizer<4,>=2 in /usr/local/lib/python3.13/site-packages (from requests>=2.32.2->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (3.4.7)
Requirement already satisfied: urllib3<3,>=1.26 in /usr/local/lib/python3.13/site-packages (from requests>=2.32.2->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.6.3)
Collecting absl-py (from rouge-score>=0.0.4->lm_eval==0.4.9.1)
  Downloading absl_py-2.4.0-py3-none-any.whl.metadata (3.3 kB)
Collecting nltk (from rouge-score>=0.0.4->lm_eval==0.4.9.1)
  Downloading nltk-3.9.4-py3-none-any.whl.metadata (3.2 kB)
Requirement already satisfied: six>=1.14.0 in /usr/local/lib/python3.13/site-packages (from rouge-score>=0.0.4->lm_eval==0.4.9.1) (1.17.0)
Collecting portalocker (from sacrebleu>=1.5.0->lm_eval==0.4.9.1)
  Downloading portalocker-3.2.0-py3-none-any.whl.metadata (8.7 kB)
Requirement already satisfied: regex in /usr/local/lib/python3.13/site-packages (from sacrebleu>=1.5.0->lm_eval==0.4.9.1) (2026.4.4)
Collecting tabulate>=0.8.9 (from sacrebleu>=1.5.0->lm_eval==0.4.9.1)
  Downloading tabulate-0.10.0-py3-none-any.whl.metadata (40 kB)
Collecting colorama (from sacrebleu>=1.5.0->lm_eval==0.4.9.1)
  Downloading colorama-0.4.6-py2.py3-none-any.whl.metadata (17 kB)
Collecting lxml (from sacrebleu>=1.5.0->lm_eval==0.4.9.1)
  Downloading lxml-6.0.4-cp313-cp313-manylinux_2_26_x86_64.manylinux_2_28_x86_64.whl.metadata (3.1 kB)
Collecting scipy>=1.10.0 (from scikit-learn>=0.24.1->lm_eval==0.4.9.1)
  Downloading scipy-1.17.1-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (62 kB)
Collecting joblib>=1.3.0 (from scikit-learn>=0.24.1->lm_eval==0.4.9.1)
  Downloading joblib-1.5.3-py3-none-any.whl.metadata (5.5 kB)
Collecting threadpoolctl>=3.2.0 (from scikit-learn>=0.24.1->lm_eval==0.4.9.1)
  Downloading threadpoolctl-3.6.0-py3-none-any.whl.metadata (13 kB)
Collecting setuptools<82 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading setuptools-81.0.0-py3-none-any.whl.metadata (6.6 kB)
Collecting sympy>=1.13.3 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading sympy-1.14.0-py3-none-any.whl.metadata (12 kB)
Collecting networkx>=2.5.1 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading networkx-3.6.1-py3-none-any.whl.metadata (6.8 kB)
Requirement already satisfied: jinja2 in /usr/local/lib/python3.13/site-packages (from torch>=1.8->lm_eval==0.4.9.1) (3.1.6)
Collecting cuda-toolkit==13.0.2 (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading cuda_toolkit-13.0.2-py2.py3-none-any.whl.metadata (9.4 kB)
Collecting cuda-bindings<14,>=13.0.3 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading cuda_bindings-13.2.0-cp313-cp313-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl.metadata (2.3 kB)
Collecting nvidia-cudnn-cu13==9.19.0.56 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cudnn_cu13-9.19.0.56-py3-none-manylinux_2_27_x86_64.whl.metadata (1.9 kB)
Collecting nvidia-cusparselt-cu13==0.8.0 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cusparselt_cu13-0.8.0-py3-none-manylinux2014_x86_64.whl.metadata (12 kB)
Collecting nvidia-nccl-cu13==2.28.9 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_nccl_cu13-2.28.9-py3-none-manylinux_2_18_x86_64.whl.metadata (2.0 kB)
Collecting nvidia-nvshmem-cu13==3.4.5 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_nvshmem_cu13-3.4.5-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (2.1 kB)
Collecting triton==3.6.0 (from torch>=1.8->lm_eval==0.4.9.1)
  Downloading triton-3.6.0-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cublas==13.1.0.3.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cublas-13.1.0.3-py3-none-manylinux_2_27_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cuda-runtime==13.0.96.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cuda_runtime-13.0.96-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cufft==12.0.0.61.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cufft-12.0.0.61-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (1.8 kB)
Collecting nvidia-cufile==1.15.1.6.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cufile-1.15.1.6-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cuda-cupti==13.0.85.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cuda_cupti-13.0.85-py3-none-manylinux_2_25_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-curand==10.4.0.35.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_curand-10.4.0.35-py3-none-manylinux_2_27_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cusolver==12.0.4.66.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cusolver-12.0.4.66-py3-none-manylinux_2_27_x86_64.whl.metadata (1.8 kB)
Collecting nvidia-cusparse==12.6.3.3.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cusparse-12.6.3.3-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl.metadata (1.8 kB)
Collecting nvidia-nvjitlink==13.0.88.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_nvjitlink-13.0.88-py3-none-manylinux2010_x86_64.manylinux_2_12_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-cuda-nvrtc==13.0.88.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_cuda_nvrtc-13.0.88-py3-none-manylinux2010_x86_64.manylinux_2_12_x86_64.whl.metadata (1.7 kB)
Collecting nvidia-nvtx==13.0.85.* (from cuda-toolkit[cublas,cudart,cufft,cufile,cupti,curand,cusolver,cusparse,nvjitlink,nvrtc,nvtx]==13.0.2; platform_system == "Linux"->torch>=1.8->lm_eval==0.4.9.1)
  Downloading nvidia_nvtx-13.0.85-py3-none-manylinux1_x86_64.manylinux_2_5_x86_64.whl.metadata (1.8 kB)
Collecting cuda-pathfinder~=1.1 (from cuda-bindings<14,>=13.0.3->torch>=1.8->lm_eval==0.4.9.1)
  Downloading cuda_pathfinder-1.5.3-py3-none-any.whl.metadata (1.9 kB)
Collecting mpmath<1.4,>=1.1.0 (from sympy>=1.13.3->torch>=1.8->lm_eval==0.4.9.1)
  Downloading mpmath-1.3.0-py3-none-any.whl.metadata (8.6 kB)
Requirement already satisfied: tokenizers<=0.23.0,>=0.22.0 in /usr/local/lib/python3.13/site-packages (from transformers>=4.1->lm_eval==0.4.9.1) (0.22.2)
Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.13/site-packages (from jinja2->torch>=1.8->lm_eval==0.4.9.1) (3.0.3)
Requirement already satisfied: click in /usr/local/lib/python3.13/site-packages (from nltk->rouge-score>=0.0.4->lm_eval==0.4.9.1) (8.1.8)
Requirement already satisfied: python-dateutil>=2.8.2 in /usr/local/lib/python3.13/site-packages (from pandas->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.9.0.post0)
Collecting DataProperty<2,>=1.1.0 (from pytablewriter->lm_eval==0.4.9.1)
  Downloading DataProperty-1.1.0-py3-none-any.whl.metadata (11 kB)
Collecting mbstrdecoder<2,>=1.0.0 (from pytablewriter->lm_eval==0.4.9.1)
  Downloading mbstrdecoder-1.1.4-py3-none-any.whl.metadata (4.3 kB)
Collecting pathvalidate<4,>=2.3.0 (from pytablewriter->lm_eval==0.4.9.1)
  Downloading pathvalidate-3.3.1-py3-none-any.whl.metadata (12 kB)
Collecting tabledata<2,>=1.3.1 (from pytablewriter->lm_eval==0.4.9.1)
  Downloading tabledata-1.3.4-py3-none-any.whl.metadata (3.7 kB)
Collecting tcolorpy<1,>=0.0.5 (from pytablewriter->lm_eval==0.4.9.1)
  Downloading tcolorpy-0.1.7-py3-none-any.whl.metadata (6.3 kB)
Collecting typepy<2,>=1.3.2 (from typepy[datetime]<2,>=1.3.2->pytablewriter->lm_eval==0.4.9.1)
  Downloading typepy-1.3.4-py3-none-any.whl.metadata (9.2 kB)
Collecting chardet<6,>=3.0.4 (from mbstrdecoder<2,>=1.0.0->pytablewriter->lm_eval==0.4.9.1)
  Downloading chardet-5.2.0-py3-none-any.whl.metadata (3.4 kB)
Collecting pytz>=2018.9 (from typepy[datetime]<2,>=1.3.2->pytablewriter->lm_eval==0.4.9.1)
  Downloading pytz-2026.1.post1-py2.py3-none-any.whl.metadata (22 kB)
Requirement already satisfied: shellingham>=1.3.0 in /usr/local/lib/python3.13/site-packages (from typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (1.5.4)
Requirement already satisfied: rich>=10.11.0 in /usr/local/lib/python3.13/site-packages (from typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (15.0.0)
Requirement already satisfied: annotated-doc>=0.0.2 in /usr/local/lib/python3.13/site-packages (from typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.0.4)
Requirement already satisfied: markdown-it-py>=2.2.0 in /usr/local/lib/python3.13/site-packages (from rich>=10.11.0->typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (4.0.0)
Requirement already satisfied: pygments<3.0.0,>=2.13.0 in /usr/local/lib/python3.13/site-packages (from rich>=10.11.0->typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (2.20.0)
Requirement already satisfied: mdurl~=0.1 in /usr/local/lib/python3.13/site-packages (from markdown-it-py>=2.2.0->rich>=10.11.0->typer->huggingface-hub>=0.24.0->datasets<4.0,>=2.16.0->lm_eval==0.4.9.1) (0.1.2)
Downloading datasets-3.6.0-py3-none-any.whl (491 kB)
Downloading dill-0.3.8-py3-none-any.whl (116 kB)
Downloading fsspec-2025.3.0-py3-none-any.whl (193 kB)
Downloading multiprocess-0.70.16-py312-none-any.whl (146 kB)
Downloading accelerate-1.13.0-py3-none-any.whl (383 kB)
Downloading evaluate-0.4.6-py3-none-any.whl (84 kB)
Downloading peft-0.19.0-py3-none-any.whl (680 kB)
Downloading pybind11-3.0.3-py3-none-any.whl (313 kB)
Downloading sacrebleu-2.6.0-py3-none-any.whl (100 kB)
Downloading safetensors-0.7.0-cp38-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (507 kB)
Downloading scikit_learn-1.8.0-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl (8.9 MB)
Downloading joblib-1.5.3-py3-none-any.whl (309 kB)
Downloading scipy-1.17.1-cp313-cp313-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl (35.2 MB)
Downloading tabulate-0.10.0-py3-none-any.whl (39 kB)
Downloading threadpoolctl-3.6.0-py3-none-any.whl (18 kB)
Downloading torch-2.11.0-cp313-cp313-manylinux_2_28_x86_64.whl (530.7 MB)

```

# Step 27 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat <<'EOF' > /app/lm-evaluation-harness/lm_eval/tasks/escitask/esci.yaml
task: esci
dataset_path: /app/esci.jsonl
dataset_name: null
output_type: multiple_choice
doc_to_text: "Is the following product title relevant to the query? Query: {{query}} Product Title: {{product_title}}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant."
doc_to_choice: ["E", "S", "C", "I"]
doc_to_target: esci_label
metric_list:
  - metric: acc
    aggregation: mean
    higher_is_better: true
EOF
```

## Agent's Analysis

Directory's made. Now, `esci.yaml` goes in it.

## Terminal Output

```

```

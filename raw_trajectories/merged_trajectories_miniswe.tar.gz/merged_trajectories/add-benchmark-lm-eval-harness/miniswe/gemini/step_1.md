# Step 1 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
git clone https://github.com/amazon-science/esci-data.git
```

## Agent's Analysis

I'll start by cloning the `esci-data` repository to access the dataset. This will allow me to extract the necessary data for creating the test set.

## Terminal Output

```
Cloning into 'esci-data'...

```

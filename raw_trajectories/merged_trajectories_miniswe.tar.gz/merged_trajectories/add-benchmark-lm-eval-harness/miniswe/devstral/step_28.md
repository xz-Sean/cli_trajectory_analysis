# Step 28 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /tmp && python3 << 'EOF'
import urllib.request
import re

# Try to get the KDD Cup page
url = "https://amazonkddcup.github.io/"
try:
    with urllib.request.urlopen(url) as response:
        html = response.read().decode('utf-8')
        # Look for links
        links = re.findall(r'href="([^"]+)"', html)
        for link in links:
            if 'esci' in link.lower() or 'data' in link.lower() or 'shopping' in link.lower():
                print(f"Found link: {link}")
except Exception as e:
    print(f"Error: {e}")
EOF

```

## Agent's Analysis

Let me try to find the actual data download link:

## Terminal Output

```
Found link: #data
Found link: https://www.aicrowd.com/challenges/esci-challenge-for-improving-product-search
Found link: https://github.com/cuixuage/KDDCup2022-ESCI
Found link: https://github.com/ChengHSUHSU/KDD_Cup2022_AmazonProductSearchESCI
Found link: https://github.com/amazon-research/esci-code

```

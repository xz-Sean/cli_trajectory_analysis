# Step 57 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat > /app/lm-evaluation-harness/lm_eval/tasks/escitask/esci.yaml << 'EOF'
tag:
  - multiple_choice
task: esci
dataset_path: /app/esci.jsonl
dataset_name: null
output_type: multiple_choice
training_split: null
validation_split: null
test_split: null
process_docs: !function utils.process_docs
doc_to_text: "Is the following product title relevant to the query? Query: {{query}} Product Title: {{product_title}}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant."
doc_to_target: "{{esci_label}}"
doc_to_choice: "choices"
metric_list:
  - metric: acc
    aggregation: mean
    higher_is_better: true
metadata:
  version: 1.0
EOF

```

## Agent's Analysis



## Terminal Output

```

```

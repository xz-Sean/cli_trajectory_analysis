# Step 54 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app/lm-evaluation-harness/lm_eval/tasks && find . -name "utils.py" | head -5
```

## Agent's Analysis

Perfect! This is exactly what I need. Now let me look at the utils to understand how to process the docs:

## Terminal Output

```
./bbh/cot_zeroshot/utils.py
./bbh/zeroshot/utils.py
./eus_reading/utils.py
./arabic_leaderboard_light/arabic_leaderboard_arabic_mt_mmlu_light/utils.py
./arabic_leaderboard_light/arabic_leaderboard_avca_light/utils.py

```

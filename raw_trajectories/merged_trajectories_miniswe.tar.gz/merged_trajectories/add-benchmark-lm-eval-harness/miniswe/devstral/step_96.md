# Step 96 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat > /app/test_esci_task.py << 'EOF'
#!/usr/bin/env python3
import sys
sys.path.insert(0, '/app/lm-evaluation-harness')

import datasets
from lm_eval.tasks.escitask.utils import process_docs
from lm_eval.api.task import ConfigurableTask

def test_esci_task():
    print("Testing ESCI Task...")
    
    # Load the dataset
    print("1. Loading dataset...")
    dataset = datasets.load_dataset('json', data_files='/app/esci.jsonl', split='train')
    print(f"   Loaded {len(dataset)} examples")
    
    # Process the docs
    print("2. Processing documents...")
    processed_dataset = process_docs(dataset)
    print(f"   Processed {len(processed_dataset)} examples")
    
    # Check the structure
    print("3. Checking data structure...")
    sample = processed_dataset[0]
    print(f"   Sample keys: {list(sample.keys())}")
    print(f"   Choices: {sample['choices']}")
    print(f"   Gold index: {sample['gold']}")
    print(f"   Query: {sample['query']}")
    print(f"   Product title: {sample['product_title']}")
    
    # Verify label mapping
    print("4. Verifying label mapping...")
    label_counts = {
        'E': sum(1 for doc in processed_dataset if doc['esci_label'] == 'E'),
        'S': sum(1 for doc in processed_dataset if doc['esci_label'] == 'S'),
        'C': sum(1 for doc in processed_dataset if doc['esci_label'] == 'C'),
        'I': sum(1 for doc in processed_dataset if doc['esci_label'] == 'I'),
    }
    print(f"   Label distribution: {label_counts}")
    
    # Verify gold indices
    print("5. Verifying gold indices...")
    gold_indices = set(doc['gold'] for doc in processed_dataset)
    print(f"   Unique gold indices: {gold_indices}")
    
    # Check that all gold indices are valid (0-3)
    invalid_indices = [doc['gold'] for doc in processed_dataset if doc['gold'] not in {0, 1, 2, 3}]
    if invalid_indices:
        print(f"   ERROR: Found invalid gold indices: {invalid_indices[:10]}")
        return False
    else:
        print("   All gold indices are valid (0-3)")
    
    print("\n✓ ESCI Task test passed!")
    return True

if __name__ == "__main__":
    success = test_esci_task()
    sys.exit(0 if success else 1)
EOF
chmod +x /app/test_esci_task.py

```

## Agent's Analysis

Great! Now let me create a simple test script to verify the task can be loaded and evaluated:

## Terminal Output

```

```

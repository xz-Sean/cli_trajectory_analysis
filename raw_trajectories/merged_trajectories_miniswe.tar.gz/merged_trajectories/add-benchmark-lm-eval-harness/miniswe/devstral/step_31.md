# Step 31 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
aicrowd login --help
```

## Agent's Analysis



## Terminal Output

```
Usage: aicrowd login [OPTIONS]

  Log in using AIcrowd API Key

Options:
  --api-key TEXT  API Key from AIcrowd website
  --help          Show this message and exit.

```

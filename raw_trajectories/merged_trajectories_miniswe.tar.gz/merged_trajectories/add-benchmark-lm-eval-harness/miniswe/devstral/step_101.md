# Step 101 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat > /app/verify_task.py << 'EOF'
#!/usr/bin/env python3
"""
Verification script for the ESCI task implementation.
This script verifies that:
1. The esci.jsonl file exists and has the correct format
2. The task YAML file is properly configured
3. The utils.py file correctly processes the data
4. The prompt is correctly formatted
"""

import sys
import json
import os
sys.path.insert(0, '/app/lm-evaluation-harness')

import datasets
from lm_eval.tasks.escitask.utils import process_docs
from jinja2 import Environment

def verify_esci_jsonl():
    """Verify the esci.jsonl file"""
    print("1. Verifying esci.jsonl file...")
    
    if not os.path.exists('/app/esci.jsonl'):
        print("   ✗ esci.jsonl file not found!")
        return False
    
    # Check file size
    file_size = os.path.getsize('/app/esci.jsonl')
    print(f"   File size: {file_size / (1024*1024):.2f} MB")
    
    # Check line count
    with open('/app/esci.jsonl', 'r', encoding='utf-8') as f:
        line_count = sum(1 for _ in f)
    
    print(f"   Number of examples: {line_count}")
    
    if line_count != 93347:
        print(f"   ✗ Expected 93347 examples, got {line_count}")
        return False
    
    # Check first example format
    with open('/app/esci.jsonl', 'r', encoding='utf-8') as f:
        first_line = json.loads(f.readline())
        required_keys = ['query', 'esci_label', 'product_locale', 'product_title']
        
        for key in required_keys:
            if key not in first_line:
                print(f"   ✗ Missing required key: {key}")
                return False
        
        if first_line['product_locale'] != 'es':
            print(f"   ✗ Expected product_locale='es', got {first_line['product_locale']}")
            return False
        
        if first_line['esci_label'] not in ['E', 'S', 'C', 'I']:
            print(f"   ✗ Invalid esci_label: {first_line['esci_label']}")
            return False
    
    print("   ✓ esci.jsonl file is valid")
    return True

def verify_task_yaml():
    """Verify the task YAML configuration"""
    print("2. Verifying task YAML configuration...")
    
    yaml_path = '/app/lm-evaluation-harness/lm_eval/tasks/escitask/esci.yaml'
    
    if not os.path.exists(yaml_path):
        print("   ✗ Task YAML file not found!")
        return False
    
    # Read and check YAML content
    with open(yaml_path, 'r') as f:
        content = f.read()
    
    required_fields = [
        'task: esci',
        'dataset_path: /app/esci.jsonl',
        'output_type: multiple_choice',
        'doc_to_text:',
        'doc_to_target:',
        'doc_to_choice:',
        'metric_list:',
        'acc'
    ]
    
    for field in required_fields:
        if field not in content:
            print(f"   ✗ Missing required field: {field}")
            return False
    
    # Check prompt format
    if 'Is the following product title relevant to the query?' not in content:
        print("   ✗ Prompt format is incorrect")
        return False
    
    if '{{query}}' not in content or '{{product_title}}' not in content:
        print("   ✗ Missing template variables in prompt")
        return False
    
    print("   ✓ Task YAML configuration is valid")
    return True

def verify_utils():
    """Verify the utils.py processing function"""
    print("3. Verifying utils.py processing function...")
    
    utils_path = '/app/lm-evaluation-harness/lm_eval/tasks/escitask/utils.py'
    
    if not os.path.exists(utils_path):
        print("   ✗ utils.py file not found!")
        return False
    
    # Load a small sample and test processing
    dataset = datasets.load_dataset('json', data_files='/app/esci.jsonl', split='train')
    small_dataset = dataset.select(range(10))
    
    try:
        processed = process_docs(small_dataset)
        
        # Check processed data structure
        if len(processed) != 10:
            print(f"   ✗ Expected 10 processed examples, got {len(processed)}")
            return False
        
        sample = processed[0]
        
        # Check required fields
        required_fields = ['query', 'product_title', 'choices', 'gold']
        for field in required_fields:
            if field not in sample:
                print(f"   ✗ Missing required field in processed data: {field}")
                return False
        
        # Check choices
        if sample['choices'] != ['E', 'S', 'C', 'I']:
            print(f"   ✗ Incorrect choices: {sample['choices']}")
            return False
        
        # Check gold index
        if sample['gold'] not in [0, 1, 2, 3]:
            print(f"   ✗ Invalid gold index: {sample['gold']}")
            return False
        
        # Verify gold index matches label
        label = sample['esci_label']
        expected_gold = 0 if label == 'E' else 1 if label == 'S' else 2 if label == 'C' else 3
        if sample['gold'] != expected_gold:
            print(f"   ✗ Gold index {sample['gold']} doesn't match label {label}")
            return False
        
        print("   ✓ utils.py processing function is valid")
        return True
        
    except Exception as e:
        print(f"   ✗ Error processing data: {e}")
        return False

def verify_prompt():
    """Verify the prompt generation"""
    print("4. Verifying prompt generation...")
    
    # Test prompt template
    template_str = "Is the following product title relevant to the query? Query: {{query}} Product Title: {{product_title}}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant."
    
    env = Environment()
    template = env.from_string(template_str)
    
    # Test with sample data
    test_data = {
        'query': 'zapatos Nike',
        'product_title': 'Zapatos deportivos Nike Air Max'
    }
    
    prompt = template.render(**test_data)
    
    # Check prompt contains expected elements
    if 'Query:' not in prompt or 'Product Title:' not in prompt:
        print("   ✗ Prompt missing required elements")
        return False
    
    if 'E for Exact' not in prompt or 'S for Substitute' not in prompt:
        print("   ✗ Prompt missing label descriptions")
        return False
    
    print(f"   Generated prompt: {prompt[:100]}...")
    print("   ✓ Prompt generation is valid")
    return True

def main():
    print("=" * 60)
    print("ESCI Task Verification")
    print("=" * 60)
    print()
    
    all_passed = True
    
    all_passed &= verify_esci_jsonl()
    print()
    all_passed &= verify_task_yaml()
    print()
    all_passed &= verify_utils()
    print()
    all_passed &= verify_prompt()
    
    print()
    print("=" * 60)
    if all_passed:
        print("✓ All verifications passed!")
        print("=" * 60)
        return 0
    else:
        print("✗ Some verifications failed!")
        print("=" * 60)
        return 1

if __name__ == "__main__":
    sys.exit(main())
EOF
chmod +x /app/verify_task.py

```

## Agent's Analysis

Excellent! Everything is working correctly. Let me create a final verification script to ensure the task is properly set up:

## Terminal Output

```

```

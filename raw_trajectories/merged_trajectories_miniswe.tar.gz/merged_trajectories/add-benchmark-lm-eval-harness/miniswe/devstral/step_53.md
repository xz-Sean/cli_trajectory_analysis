# Step 53 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app/lm-evaluation-harness/lm_eval/tasks && cat ./hellaswag/hellaswag.yaml
```

## Agent's Analysis

Let me try a different approach and look at a specific task:

## Terminal Output

```
tag:
  - multiple_choice
task: hellaswag
dataset_path: Rowan/hellaswag
dataset_name: null
output_type: multiple_choice
training_split: train
validation_split: validation
test_split: null
process_docs: !function utils.process_docs
doc_to_text: "{{query}}"
doc_to_target: "{{label}}"
doc_to_choice: "choices"
metric_list:
  - metric: acc
    aggregation: mean
    higher_is_better: true
  - metric: acc_norm
    aggregation: mean
    higher_is_better: true
metadata:
  version: 1.0

```

# Step 2 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
mkdir -p /srv/shared
chmod 2770 /srv/shared
chown root:research /srv/shared
setfacl -R -m u::rwx /srv/shared
setfacl -R -m g::rwx /srv/shared
setfacl -R -m m::rwx /srv/shared
setfacl -R -m u:alice:rwx /srv/shared
setfacl -R -m u:bob:rwx /srv/shared
setfacl -R -m g:research:rwx /srv/shared
setfacl -R -d -m u::rwx /srv/shared
setfacl -R -d -m g::rwx /srv/shared
setfacl -R -d -m m::rwx /srv/shared
setfacl -R -d -m u:alice:rwx /srv/shared
setfacl -R -d -m u:bob:rwx /srv/shared
setfacl -R -d -m g:research:rwx /srv/shared
setfacl -R -m o::--- /srv/shared
setfacl -R -d -m o::--- /srv/shared
```

## Agent's Analysis

The research group exists with GID 1001 and contains both alice and bob. Users alice (UID 1001) and bob (UID 1002) also exist. Now I need to create the /srv/shared directory with the correct permissions (2770), setgid bit, ownership (root:research), and configure the ACLs for proper inheritance.

Plan: 1. Create /srv/shared directory with permissions 2770 (setgid bit included)
2. Set ownership to root:research
3. Apply ACLs with both current and default entries for research group, alice, and bob
4. Set the mask to allow full permissions
5. Verify the ACL configuration

## Terminal Output

```
root@bda882ab18c3:/app# mkdir -p /srv/shared
root@bda882ab18c3:/app# chmod 2770 /srv/shared
root@bda882ab18c3:/app# chown root:research /srv/shared
root@bda882ab18c3:/app# setfacl -R -m u::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m g::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m m::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m u:alice:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m u:bob:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m g:research:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m u::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m g::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m m::rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m u:alice:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m u:bob:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m g:research:rwx /srv/shared
root@bda882ab18c3:/app# setfacl -R -m o::--- /srv/shared
root@bda882ab18c3:/app# setfacl -R -d -m o::--- /srv/shared
root@bda882ab18c3:/app#
```

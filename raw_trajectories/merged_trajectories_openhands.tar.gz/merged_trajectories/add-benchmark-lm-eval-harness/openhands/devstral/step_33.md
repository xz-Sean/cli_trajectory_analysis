# Step 33 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/KDD_Cup2022_AmazonProductSearchESCI/data_process.py
```

## Agent's Analysis

This script shows that the data was downloaded from the AIcrowd challenge. Let me check if there's any information about the products file in the data processing script:

## Terminal Output

```
Here's the result of running `cat -n` on /app/KDD_Cup2022_AmazonProductSearchESCI/data_process.py:
     1	   
     2	
     3	import re
     4	import random
     5	import pickle
     6	import pandas as pd
     7	from tqdm import tqdm
     8	
     9	from utils import convert_q_pdi_to_q_sent_feature
    10	from utils import convert_pdi_pdi_to_sent_feature
    11	
    12	from torch.utils.data import DataLoader
    13	from sentence_transformers import InputExample
    14	
    15	
    16	
    17	
    18	def data_info_process(args=None):
    19	    # load data from pickle
    20	    if args.model_cfg['downstream_load_pkl'] is True:
    21	        try:
    22	            data_info_path = args.model_cfg['data_info_path']
    23	            target_fold = args.model_cfg['target_fold']
    24	            path = data_info_path + '_{}fold.pkl'.format(str(target_fold))
    25	            with open(path, "rb") as f:
    26	                data = pickle.load(f)
    27	            data_info = data['data_info']
    28	            return data_info
    29	        except:
    30	            print('[Warning] : Cannot load train-data.pkl..., please check config again')
    31	
    32	    # load data (task1, task2)
    33	    print('load data ...')
    34	    task1_path = args.data_process_cfg['task1_path']
    35	    train_path = task1_path + 'train-v0.2.csv'
    36	    test_path = task1_path + 'test_public-v0.3.csv'
    37	    product_path = task1_path + 'product_catalogue-v0.2.csv'
    38	    submit_path = task1_path + 'sample_submission-v0.2.csv'
    39	    train_dat = pd.read_csv(train_path)
    40	    test_dat = pd.read_csv(test_path)
    41	    product_dat = pd.read_csv(product_path)
    42	    submit_dat = pd.read_csv(submit_path)
    43	    #task2_path = args.data_process_cfg['task2_path']
    44	    #task2_train_path = task2_path + 'train-v0.2.csv'
    45	    #task2_product_path = task2_path + 'product_catalogue-v0.2.csv'
    46	    #task2_train_dat = pd.read_csv(task2_train_path)
    47	
    48	    # imputation
    49	    print('imputation ...')
    50	    train_dat = train_dat.fillna('Empty')

```

# Step 25 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app && git clone https://github.com/amazon-science/esci-code.git
```

## Agent's Analysis

This script shows that they're working with the examples file and using query_id and product_id to map to BERT representations, but it doesn't show where the product titles come from. Let me check if there's any information in the original repository or if I need to look for the products file elsewhere.

Let me check the original Amazon Science ESCI repository to see if the products file is available there:

## Terminal Output

```
Cloning into 'esci-code'...
Username for 'https://github.com':
```

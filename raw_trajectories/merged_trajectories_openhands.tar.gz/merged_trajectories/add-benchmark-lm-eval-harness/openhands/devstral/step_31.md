# Step 31 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/KDD_Cup2022_AmazonProductSearchESCI
```

## Agent's Analysis



## Terminal Output

```
Here's the files and directories up to 2 levels deep in /app/KDD_Cup2022_AmazonProductSearchESCI, excluding hidden items:
/app/KDD_Cup2022_AmazonProductSearchESCI/
/app/KDD_Cup2022_AmazonProductSearchESCI/README.md
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/bert_model.cpython-36.pyc
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/data_process.cpython-36.pyc
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/model.cpython-36.pyc
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/util.cpython-36.pyc
/app/KDD_Cup2022_AmazonProductSearchESCI/__pycache__/utils.cpython-36.pyc
/app/KDD_Cup2022_AmazonProductSearchESCI/bert_model.py
/app/KDD_Cup2022_AmazonProductSearchESCI/config/
/app/KDD_Cup2022_AmazonProductSearchESCI/config/data_process.yaml
/app/KDD_Cup2022_AmazonProductSearchESCI/config/mix_model.yaml
/app/KDD_Cup2022_AmazonProductSearchESCI/config/model_classifier/
/app/KDD_Cup2022_AmazonProductSearchESCI/config/model_mse/
/app/KDD_Cup2022_AmazonProductSearchESCI/config/model_two_stage_mse_marginrank/
/app/KDD_Cup2022_AmazonProductSearchESCI/config/model_two_stage_mse_mse/
/app/KDD_Cup2022_AmazonProductSearchESCI/data/
/app/KDD_Cup2022_AmazonProductSearchESCI/data/download_data.sh
/app/KDD_Cup2022_AmazonProductSearchESCI/data_process.py
/app/KDD_Cup2022_AmazonProductSearchESCI/main.py
/app/KDD_Cup2022_AmazonProductSearchESCI/model.py
/app/KDD_Cup2022_AmazonProductSearchESCI/paper.pdf
/app/KDD_Cup2022_AmazonProductSearchESCI/requirement.txt
/app/KDD_Cup2022_AmazonProductSearchESCI/save_log/
/app/KDD_Cup2022_AmazonProductSearchESCI/save_log/readme.txt
/app/KDD_Cup2022_AmazonProductSearchESCI/save_model/
/app/KDD_Cup2022_AmazonProductSearchESCI/save_model/readme
/app/KDD_Cup2022_AmazonProductSearchESCI/share.py
/app/KDD_Cup2022_AmazonProductSearchESCI/task_1_query-product_ranking/
/app/KDD_Cup2022_AmazonProductSearchESCI/task_1_query-product_ranking/readme
/app/KDD_Cup2022_AmazonProductSearchESCI/task_2_multiclass_product_classification/
/app/KDD_Cup2022_AmazonProductSearchESCI/task_2_multiclass_product_classification/readme
/app/KDD_Cup2022_AmazonProductSearchESCI/utils.py

2 hidden files/directories in this directory are excluded. You can use 'ls -la /app/KDD_Cup2022_AmazonProductSearchESCI' to see them.
```

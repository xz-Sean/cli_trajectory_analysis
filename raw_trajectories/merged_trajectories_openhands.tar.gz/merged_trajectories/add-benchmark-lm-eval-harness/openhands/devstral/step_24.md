# Step 24 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/esci-data/classification_identification/build_input_data_model.py
```

## Agent's Analysis

Let me check the original paper or documentation to see if there's information about where to get the products file. Let me also check if there are any scripts that might show how to access the products data:

## Terminal Output

```
Here's the result of running `cat -n` on /app/esci-data/classification_identification/build_input_data_model.py:
     1	# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
     2	# 
     3	#   Licensed under the Apache License, Version 2.0 (the "License").
     4	#   You may not use this file except in compliance with the License.
     5	#   You may obtain a copy of the License at
     6	#  
     7	#       http://www.apache.org/licenses/LICENSE-2.0
     8	#  
     9	#   Unless required by applicable law or agreed to in writing, software
    10	#   distributed under the License is distributed on an "AS IS" BASIS,
    11	#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    12	#   See the License for the specific language governing permissions and
    13	#   limitations under the License.
    14	
    15	import argparse
    16	import numpy as np
    17	import os
    18	import pandas as pd
    19	from tqdm import tqdm
    20	
    21	
    22	def main():
    23	    
    24	    parser = argparse.ArgumentParser()
    25	    parser.add_argument("dataset_path", type=str, help="Directory where the dataset is stored.")
    26	    parser.add_argument("split", type=str, choices=['train', 'test'], help="Split of the dataset.")
    27	    parser.add_argument("dict_products_path_file", type=str, help="Input file with the mapping of the products to BERT representations.")
    28	    parser.add_argument("dict_queries_path_file", type=str, help="Input file with the mapping of the queries to BERT representations.")
    29	    parser.add_argument("output_queries_path_file", type=str, help="Output array file with the BERT representations of the queries.")
    30	    parser.add_argument("output_products_path_file", type=str, help="Output array file with the BERT representations of the products.")
    31	    parser.add_argument("output_labels_path_file", type=str, default=None, help="Output array file the labels.")
    32	    parser.add_argument("--labels_type", type=str, choices=["esci_labels", "substitute_identification"], help="Task: esci_labels | substitute_identification.")
    33	    parser.add_argument("--bert_size", type=int, default=768, help="BERT embeddings dimension.")
    34	    args = parser.parse_args()
    35	
    36	    """" 1. Init variables """
    37	    col_label = "esci_label"
    38	    col_query_id = "query_id"
    39	    col_product_id = "product_id" 
    40	    col_large_version = "large_version"
    41	    col_split = "split"
    42	    col_esci_label = "esci_label"
    43	
    44	    dict_labels_type = dict()
    45	    dict_labels_type['esci_labels'] = {
    46	        'E' : 0,
    47	        'S' : 1,
    48	        'C' : 2,
    49	        'I' : 3,
    50	    }
    51	    dict_labels_type['substitute_identification'] = {
    52	        'no_substitute' : 0,
    53	        'substitute' : 1,
    54	    }
    55	
    56	    """" 2. Load data """
    57	    dict_products = np.load(args.dict_products_path_file, allow_pickle=True)
    58	    dict_queries = np.load(args.dict_queries_path_file, allow_pickle=True)
    59	    df = pd.read_parquet(os.path.join(args.dataset_path, 'shopping_queries_dataset_examples.parquet'))
    60	    df = df[df[col_large_version] == 1]
    61	    df = df[df[col_split] == args.split]
    62	    
    63	    df = df[[
    64	        col_query_id,
    65	        col_product_id,
    66	        col_esci_label,
    67	    ]]
    68	    
    69	    if args.labels_type == "substitute_identification":
    70	        tmp_dict = {
    71	            'E' : 'no_substitute',
    72	            'S' : 'substitute',
    73	            'C' : 'no_substitute',
    74	            'I' : 'no_substitute',
    75	        }
    76	        df[col_esci_label] = df[col_esci_label].apply(lambda esci_label: tmp_dict[esci_label])
    77	
    78	    num_examples = len(df)
    79	    array_queries = np.zeros((num_examples, args.bert_size))
    80	    array_products = np.zeros((num_examples, args.bert_size))
    81	    
    82	    """" 3. Map queries and products """
    83	    for i in tqdm(range(num_examples)):
    84	        array_queries[i] = dict_queries[()][df.iloc[i][col_query_id]]
    85	        array_products[i] = dict_products[()][df.iloc[i][col_product_id]]
    86	        
    87	    """" 4. Export representations for queries and products """
    88	    np.save(args.output_queries_path_file, array_queries)
    89	    np.save(args.output_products_path_file, array_products)
    90	
    91	    """" 5. Export labels (only for training) """
    92	    col_class_id = 'class_id'
    93	    labels2class_id = dict_labels_type[args.labels_type]
    94	    df[col_class_id] = df[col_label].apply(lambda label: labels2class_id[label])
    95	    np.save(args.output_labels_path_file, df[col_class_id].to_numpy())
    96	
    97	
    98	if __name__ == "__main__": 
    99	    main()  

```

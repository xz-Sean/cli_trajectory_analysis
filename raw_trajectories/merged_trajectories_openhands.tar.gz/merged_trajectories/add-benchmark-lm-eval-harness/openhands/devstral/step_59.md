# Step 59 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/lm-evaluation-harness/lm_eval/tasks/super_glue
```

## Agent's Analysis

Wait, I need to think about this more carefully. The `doc_to_target` should be the index of the correct choice, not the label itself. Let me check how other multiple choice tasks handle this. Let me look at the boolq example:

## Terminal Output

```
Here's the files and directories up to 2 levels deep in /app/lm-evaluation-harness/lm_eval/tasks/super_glue, excluding hidden items:
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/README.md
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/seq2seq.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/cb/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/cb/aggregate.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/cb/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/cb/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/cb/t5_utils.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/copa/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/copa/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/copa/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/copa/utils.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/multirc/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/multirc/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/multirc/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/multirc/t5_utils.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/record/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/record/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/record/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/record/t5_utils.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/record/util.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/rte/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/rte/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/rte/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wic/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wic/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wic/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wsc/
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wsc/default.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wsc/preprocess_wsc.py
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wsc/t5-prompt.yaml
/app/lm-evaluation-harness/lm_eval/tasks/super_glue/wsc/t5_utils.py
```

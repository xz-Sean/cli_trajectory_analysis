# Step 30 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app && git clone https://github.com/ChengHSUHSU/KDD_Cup2022_AmazonProductSearchESCI.git
```

## Agent's Analysis

Let me try to find the products data from one of the winning solutions. Let me check the GitHub repository mentioned in the KDD Cup page:

## Terminal Output

```
Cloning into 'KDD_Cup2022_AmazonProductSearchESCI'...
remote: Enumerating objects: 264, done.
remote: Counting objects: 100% (264/264), done.
remote: Compressing objects: 100% (163/163), done.
remote: Total 264 (delta 131), reused 203 (delta 73), pack-reused 0 (from 0)
Receiving objects: 100% (264/264), 534.52 KiB | 3.28 MiB/s, done.
Resolving deltas: 100% (131/131), done.
```

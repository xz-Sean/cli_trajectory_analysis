# Step 41 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/lm-evaluation-harness/docs/new_task_guide.md
```

## Agent's Analysis

Let me look at the new task guide to understand how to create a new benchmark:

## Terminal Output

```
Here's the result of running `cat -n` on /app/lm-evaluation-harness/docs/new_task_guide.md:
     1	# New Task Guide
     2	
     3	`lm-evaluation-harness` is a framework that strives to support a wide range of zero- and few-shot evaluation tasks on autoregressive language models (LMs).
     4	
     5	This documentation page provides a walkthrough to get started creating your own task, in `lm-eval` versions v0.4.0 and later.
     6	
     7	A more interactive tutorial is available as a Jupyter notebook [here](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/examples/lm-eval-overview.ipynb).
     8	
     9	## Setup
    10	
    11	If you haven't already, go ahead and fork the main repo, clone it, create a branch with the name of your task, and install the project requirements in your environment:
    12	
    13	```sh
    14	# After forking...
    15	git clone https://github.com/<YOUR-USERNAME>/lm-evaluation-harness.git
    16	cd lm-evaluation-harness
    17	git checkout -b <task-name>
    18	pip install -e ".[dev]"
    19	```
    20	
    21	In this document, we'll walk through the basics of implementing a static benchmark evaluation in two formats: a *generative* task which requires sampling text from a model, such as [`gsm8k`](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/lm_eval/tasks/gsm8k/gsm8k.yaml), and a *discriminative*, or *multiple choice*, task where the model picks the most likely of several fixed answer choices, such as [`sciq`](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/lm_eval/tasks/sciq/sciq.yaml).
    22	
    23	## Creating a YAML file
    24	
    25	To implement a new standard task, we'll need to write a YAML file which configures our task logic. We start by making a new empty YAML file. This file can have any name, but we recommend placing it in a subfolder of `lm_eval/tasks` titled by the dataset or task's shorthand name: for example,
    26	
    27	```sh
    28	touch lm_eval/tasks/<dataset_name>/<my_new_task_name>.yaml
    29	```
    30	
    31	Or, copy the template subfolder we provide from `templates/new_yaml_task`:
    32	
    33	```sh
    34	cp -r templates/new_yaml_task lm_eval/tasks/
    35	```
    36	
    37	and rename the folders and YAML file(s) as desired.
    38	
    39	### Selecting and configuring a dataset
    40	
    41	All data downloading and management is handled through the HuggingFace (**HF**) [`datasets`](https://github.com/huggingface/datasets) API. So, the first thing you should do is check to see if your task's dataset is already provided in their catalog [here](https://huggingface.co/datasets). If it's not in there, please consider adding it to their Hub to make it accessible to a wider user base by following their [new dataset guide](https://github.com/huggingface/datasets/blob/main/ADD_NEW_DATASET.md)
    42	.
    43	> [!TIP]
    44	> To test your task, we recommend using verbose logging using `export LOGLEVEL = DEBUG` in your shell before running the evaluation script. This will help you debug any issues that may arise.
    45	Once you have a HuggingFace dataset prepared for your task, we want to assign our new YAML to use this dataset:
    46	
    47	```yaml
    48	dataset_path: ... # the name of the dataset on the HF Hub.
    49	dataset_name: ... # the dataset configuration to use. Leave `null` if your dataset does not require a config to be passed. See https://huggingface.co/docs/datasets/load_hub#configurations for more info.
    50	dataset_kwargs: null # any extra keyword arguments that should be passed to the dataset constructor, e.g. `data_dir`.
    51	```
    52	
    53	Next, we'd like to tell our task what the dataset's train, validation, and test splits are named, if they exist:
    54	
    55	```yaml
    56	training_split: <split name of training set, or `null`>
    57	validation_split: <split name of val. set, or `null`>
    58	test_split: <split name of test set, or `null`>
    59	```
    60	
    61	Tests will run on the `test_split` if it is available, and otherwise evaluate on the `validation_split`.
    62	
    63	We can also specify from which split the task should retrieve few-shot examples via:
    64	
    65	```yaml
    66	fewshot_split: <split name to draw fewshot examples from, or `null`>
    67	```
    68	
    69	or by hardcoding them, either using the following in the yaml file:
    70	
    71	```yaml
    72	fewshot_config:
    73	  sampler: first_n
    74	  samples: [
    75	    {<sample 1>},
    76	    {<sample 2>},
    77	  ]
    78	```
    79	
    80	or by adding the function `list_fewshot_samples` in the associated utils.py file:
    81	
    82	```python
    83	def list_fewshot_samples() -> list[dict]:
    84	  return [{<sample 1>}, {<sample 2>}]
    85	```
    86	
    87	See `lm_eval/tasks/minerva_math/minerva_math_algebra.yaml` for an example of the latter, and `lm_eval/tasks/gsm8k/gsm8k-cot.yaml` for an example of the former.
    88	
    89	In this case, each sample must contain the same fields as the samples in the above sets--for example, if `doc_to_text` expects an `input` field when rendering input prompts, these provided samples must include an `input` key.
    90	
    91	If neither above options are not set, we will default to train/validation/test sets, in that order.
    92	
    93	Finally, our dataset may not be already in the exact format we want. Maybe we have to strip whitespace and special characters via a regex from our dataset's "question" field! Or maybe we just want to rename its columns to match a convention we'll be using for our prompts.
    94	
    95	Let's create a python file in the directory where we're writing our YAML file:
    96	
    97	```bash
    98	touch lm_eval/tasks/<dataset_name>/utils.py
    99	```
   100	

```

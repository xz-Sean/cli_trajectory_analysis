# Step 29 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cd /app && curl -s https://amazonkddcup.github.io/ | grep -i product
```

## Agent's Analysis

The sources file doesn't help with product titles. Let me try to find the products data from the original Amazon KDD Cup or other sources. Let me check if there's a way to download the products data from the official source:

## Terminal Output

```
<meta name="description" content="KDD Cup 2022 Workshop: The primary objective of this competition is to build new ranking strategies and, simultaneously, identify interesting categories of results (i.e., substitutes) that can be used to improve the customer experience when searching for products." />
        <title>KDD Cup 2022 Workshop: ESCI Challenge for Improving Product Search</title>
                <h2 class="fw-bolder">ESCI Challenge for Improving Product Search</h2>
                            KDDCup 2022 Challenge on improving product search. In this challenge, we introduce the “Shopping Queries Data Set”,
                            matching of queries and products. For each query, the dataset provides a list of up to 40 potentially relevant results,
                            product to the query. Each query-product pair is accompanied by additional information.  The dataset is multilingual,
                            <a href="https://www.aicrowd.com/challenges/esci-challenge-for-improving-product-search">https://www.aicrowd.com/challenges/esci-challenge-for-improving-product-search</a>.
                        (i.e., substitutes) that can be used to improve the customer experience when searching for products. The three different tasks for this KDD
                            <li><b>Query-Product Ranking:</b> Given a user specified query and a list of matched products, the goal of this task is to rank the products so that the relevant products are ranked above the non-relevant ones.</li>
                            <li><b>Multi-class Product Classification:</b> Given a query and a result list of products retrieved for this query, the goal of this task is to classify each product as being an Exact, Substitute, Complement, or Irrelevant match for the query.</li>
                            <li><b>Product Substitute Identification:</b> This task will measure the ability of the systems to identify the substitute products in the list of results for a given query.</li>
                                    <h5 class="mb-1"><span><i class="fas fa-bars-progress" style="color:#0275d8;"></i></span>&nbsp;&nbsp;Task 1: Query-Product Ranking</h5>
                                        <li>A Semantic Alignment System for Multilingual Query-Product Retrieval</li>
                                        <li>Second place solution of Amazon KDD Cup 2022: ESCI Challenge for Improving Product Search</li>
                                        <li>Solution of Team GraphMIRAcles in the KDD Cup 2022 Query-Product Ranking Task</li>
                                        <li>A simple but effective solution for Task 1 of KDD Cup 2022 Challenge on improving product search</li>
                                      <h5 class="mb-1"><span><i class="fas fa-bars-progress" style="color:#0275d8;"></i></span>&nbsp;&nbsp;Task 2 and 3: Multi-Class and Substitute Product Classification</h5>
                                            <li>A Winning Solution of KDD CUP 2022 ESCI Challenge for Improving Product Search</li>
                                            <li>Multiclass Product Classification Based On Multilingual Model and LightGBM (Team:Uni)</li>
                                            <li>ZhichunRoad at Amazon KDD Cup 2022: MultiTask Pre-Training for E-Commerce Product Search</li>
                                            <li>TFKD Solution for KDD Cup 2022 Amazon Product Search</li>
                                            <li>A Boring-yet-effective Approach for the Product Ranking Task of the Amazon KDD Cup 2022</li>
                                            <li>CMB AI Lab at KDD Cup 2022 ESCI Task2 and Task3: A Domain Adapted PLM with Context Enhancement for Query-Product Classification</li>
                                            <li>A Multi-model Fusion Approach for Product Classification and Product Substitute Identification on Shopping Queries Data</li>
                                            <li>KDD Cup 2022 Multiclass Product Classification: Team MetaSoul Solution</li>
                                <h6>A Winning Solution of KDD CUP 2022 ESCI Challenge for Improving Product Search</h6>
                                <h6>Multiclass Product Classification Based On Multilingual Model and LightGBM (Team:Uni)</h6>
                                <h6>A Semantic Alignment System for Multilingual Query-Product Retrieval</h6>
                                <h6>Second place solution of Amazon KDD Cup 2022: ESCI Challenge for Improving Product Search</h6>
                                <h6>ZhichunRoad at Amazon KDD Cup 2022: MultiTask Pre-Training for E-Commerce Product Search</h6>
                                <h6>Solution of Team GraphMIRAcles in the KDD Cup 2022 Query-Product Ranking Task</h6>
                                <h6>CMB AI Lab at KDD Cup 2022 ESCI Task2 and Task3: A Domain Adapted PLM with Context Enhancement for Query-Product Classification</h6>
                                <h6>A simple but effective solution for Task 1 of KDD Cup 2022 Challenge on improving product search</h6>
                                <h6>A Multi-model Fusion Approach for Product Classification and Product Substitute Identification on Shopping Queries Data</h6>
                                <h6>TFKD Solution for KDD Cup 2022 Amazon Product Search</h6>
                                    <a href="https://github.com/ChengHSUHSU/KDD_Cup2022_AmazonProductSearchESCI" class="btn btn-secondary" role="button" target="_blank">Code</a>
                                <h6>KDD Cup 2022 Multiclass Product Classification: Team MetaSoul Solution</h6>
                                <h6>A Boring-yet-effective Approach for the Product Ranking Task of the Amazon KDD Cup 2022</h6>
                                title={Shopping Queries Dataset: A Large-Scale {ESCI} Benchmark for Improving Product Search},<br>
```

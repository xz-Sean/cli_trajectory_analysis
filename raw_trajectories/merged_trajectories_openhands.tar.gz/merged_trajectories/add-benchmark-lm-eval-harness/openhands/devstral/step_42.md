# Step 42 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/lm-evaluation-harness/docs/new_task_guide.md
```

## Agent's Analysis

Let me continue reading the guide to understand the structure better:

## Terminal Output

```
Here's the result of running `cat -n` on /app/lm-evaluation-harness/docs/new_task_guide.md:
   100	
   101	Now, in `utils.py` we'll write a function to process each split of our dataset (the following example is drawn from [the `hellaswag` task](../lm_eval/tasks/hellaswag/utils.py)):
   102	
   103	```python
   104	def process_docs(dataset: datasets.Dataset) -> datasets.Dataset:
   105	    def _process_doc(doc):
   106	        ctx = doc["ctx_a"] + " " + doc["ctx_b"].capitalize()
   107	        out_doc = {
   108	            "query": preprocess(doc["activity_label"] + ": " + ctx),
   109	            "choices": [preprocess(ending) for ending in doc["endings"]],
   110	            "gold": int(doc["label"]),
   111	        }
   112	        return out_doc
   113	
   114	    return dataset.map(_process_doc)
   115	```
   116	
   117	Now, in our YAML config file we'll use the `!function` constructor, and tell the config where our imported Python function will come from. At runtime, before doing anything else we will preprocess our dataset according to this function!
   118	
   119	```yaml
   120	process_docs: !function utils.process_docs
   121	```
   122	
   123	### Using Local Datasets
   124	
   125	To load a local dataset for evaluation, you can specify data files in the `dataset_kwargs` field, such as the following for JSON files:
   126	
   127	```yaml
   128	dataset_path: json
   129	dataset_name: null
   130	dataset_kwargs:
   131	  data_files: /path/to/my/json
   132	```
   133	
   134	Or with files already split into separate directories:
   135	
   136	```yaml
   137	dataset_path: arrow
   138	dataset_kwargs:
   139	  data_files:
   140	    train: /path/to/arrow/train/data-00000-of-00001.arrow
   141	    validation: /path/to/arrow/validation/data-00000-of-00001.arrow
   142	```
   143	
   144	Alternatively, if you have previously downloaded a dataset from huggingface hub (using `save_to_disk()`) and wish to use the local files, you will need to use `data_dir` under `dataset_kwargs` to point to where the directory is.
   145	
   146	```yaml
   147	dataset_path: hellaswag
   148	dataset_kwargs:
   149	  data_dir: hellaswag_local/
   150	```
   151	
   152	You can also set `dataset_path` as a directory path in your local system. This will assume that there is a loading script with the same name as the directory. [See datasets docs](https://huggingface.co/docs/datasets/loading#local-loading-script).
   153	
   154	## Writing a Prompt Template
   155	
   156	The next thing we need to do is decide what format to use when presenting the data to the LM. This is our **prompt**, where we'll define both an input and output format.
   157	
   158	To write a prompt, users will use `doc_to_text`, `doc_to_target`, and `doc_to_choice` (Optional when certain conditions are met).
   159	
   160	`doc_to_text` defines the input string a model will be given while `doc_to_target` and `doc_to_choice` will be used to generate the target text. `doc_to_target` can be either a text string that refers to the target string or an integer that refers to the index of the correct label. When it is set as an index, `doc_to_choice` must also be set with the appropriate list of possible choice strings.
   161	
   162	### Basic prompts
   163	
   164	If a dataset is straightforward enough, users can enter the feature name directly. This assumes that no preprocessing is required. For example in [Swag](https://github.com/EleutherAI/lm-evaluation-harness/blob/1710b42d52d0f327cb0eb3cb1bfbbeca992836ca/lm_eval/tasks/swag/swag.yaml#L10-L11), `doc_to_text` and `doc_to_target` given the name of one of the feature each.
   165	
   166	```yaml
   167	doc_to_text: startphrase
   168	doc_to_target: label
   169	```
   170	
   171	Hard-coding is also possible as is the case in [SciQ](https://github.com/EleutherAI/lm-evaluation-harness/blob/1710b42d52d0f327cb0eb3cb1bfbbeca992836ca/lm_eval/tasks/sciq/sciq.yaml#L11).
   172	
   173	```yaml
   174	doc_to_target: 3
   175	```
   176	
   177	`doc_to_choice` can be directly given a list of text as option (See [Toxigen](https://github.com/EleutherAI/lm-evaluation-harness/blob/1710b42d52d0f327cb0eb3cb1bfbbeca992836ca/lm_eval/tasks/toxigen/toxigen.yaml#L11))
   178	
   179	```yaml
   180	doc_to_choice: ['No', 'Yes']
   181	```
   182	
   183	if a dataset feature is already a list, you can set the name of the feature as `doc_to_choice` (See [Hellaswag](https://github.com/EleutherAI/lm-evaluation-harness/blob/e0eda4d3ffa10e5f65e0976161cd134bec61983a/lm_eval/tasks/hellaswag/hellaswag.yaml#L13))
   184	
   185	```yaml
   186	doc_to_choice: choices
   187	```
   188	
   189	### Writing a prompt with Jinja 2
   190	
   191	We support the [Jinja 2](https://jinja.palletsprojects.com/en/3.1.x/) templating language for writing prompts. In practice, this means you can take your dataset's columns and do many basic string manipulations to place each document into prompted format.
   192	
   193	Take for example the dataset `super_glue/boolq`. As input, we'd like to use the features `passage` and `question` and string them together so that for a sample line `doc`, the model sees something in the format of:
   194	
   195	```text
   196	doc["passage"]
   197	Question: doc["question"]?
   198	Answer:
   199	```
   200	

```

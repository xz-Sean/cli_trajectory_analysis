# Step 60 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
[read] /app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/default.yaml
```

## Agent's Analysis



## Terminal Output

```
Here's the result of running `cat -n` on /app/lm-evaluation-harness/lm_eval/tasks/super_glue/boolq/default.yaml:
     1	tag:
     2	  - super-glue-lm-eval-v1
     3	task: boolq
     4	dataset_path: super_glue
     5	dataset_name: boolq
     6	output_type: multiple_choice
     7	training_split: train
     8	validation_split: validation
     9	doc_to_text: "{{passage}}\nQuestion: {{question}}?\nAnswer:"
    10	doc_to_target: label
    11	doc_to_choice: ["no", "yes"]
    12	should_decontaminate: true
    13	doc_to_decontamination_query: passage
    14	metric_list:
    15	  - metric: acc
    16	metadata:
    17	  version: 2.0
    18	

```

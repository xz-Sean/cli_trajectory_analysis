# Step 53 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat -n /app/lm-evaluation-harness/docs/new_task_guide.md
```

## Agent's Analysis

I read the file /app/lm-evaluation-harness/docs/new_task_guide.md.

## Terminal Output

```
Here's the result of running `cat -n` on /app/lm-evaluation-harness/docs/new_task_guide.md:
   200	
   201	We do this by [writing](https://github.com/EleutherAI/lm-evaluation-harness/blob/1710b42d52d0f327cb0eb3cb1bfbbeca992836ca/lm_eval/tasks/super_glue/boolq/default.yaml#L9C1-L9C61)
   202	
   203	```yaml
   204	doc_to_text: "{{passage}}\nQuestion: {{question}}?\nAnswer:"
   205	```
   206	
   207	Such that `{{passage}}` will be replaced by `doc["passage"]` and `{{question}}` with `doc["question"]` when rendering the prompt template.
   208	
   209	Our intended output is for the model to predict a single whitespace, and then the answer to the question. We do this via:
   210	
   211	```yaml
   212	doc_to_target: "{{answer}}"
   213	```
   214	
   215	#### Multiple choice format
   216	
   217	For tasks which are multiple choice (a fixed, finite set of label words per each document) and evaluated via comparing loglikelihoods of all label words (the `multiple_choice` task output type) we enforce a particular convention on prompt format.
   218	
   219	> [!WARNING]
   220	> We add `target_delimiter` between input and target which defaults to " ", such that the full input-output string is `doc_to_text(doc) + target_delimiter + doc_to_target(doc)`. `doc_to_text` and `doc_to_target` should not contain trailing right or left whitespace, respectively. For multiple choice the target will be each choice index concatenated with the delimiter.
   221	
   222	An annotated example in the case of SciQ is as follows:
   223	
   224	```yaml
   225	doc_to_text: "{{support.lstrip()}}\nQuestion: {{question}}\nAnswer:" # This is the input portion of the prompt for this doc. It will have " {{choice}}" appended to it as target for each choice in answer_choices.
   226	doc_to_target: 3 # this contains the index into the answer choice list of the correct answer.
   227	doc_to_choice: "{{[distractor1, distractor2, distractor3, correct_answer]}}"
   228	```
   229	
   230	Task implementers are thus able to decide what the answer choices should be for a document, and what prompt format to use.
   231	
   232	The label index can also be sourced from a feature directly. For example in `superglue/boolq`, the label index if defined in the feature `label`. We can set `doc_to_target` as simply `label`. The options or verbalizers can be written in the form of a list `["no", "yes"]` that will correspond to the label index.
   233	
   234	```yaml
   235	doc_to_text: "{{passage}}\nQuestion: {{question}}?\nAnswer:"
   236	doc_to_target: label
   237	doc_to_choice: ["no", "yes"]
   238	```
   239	
   240	### Using Python Functions for Prompts
   241	
   242	There may be cases where the prompt we want to implement is easier expressed in Python instead of Jinja 2. For this, we can use Python helper functions that are defined in the YAML config. It should be noted that the function script must be in the same directory as the yaml.
   243	
   244	A good example is WikiText that requires a lot of regex rules to clean the samples.
   245	
   246	```python
   247	def wikitext_detokenizer(doc):
   248	    string = doc["page"]
   249	    # contractions
   250	    string = string.replace("s '", "s'")
   251	    string = re.sub(r"/' [0-9]/", r"/'[0-9]/", string)
   252	    ...
   253	    string = string.replace(" 's", "'s")
   254	
   255	    return string
   256	```
   257	
   258	We can load this function in `doc_to_target` by using a `!function` operator after `doc_to_target` and followed by `<file name>.<function name>`. In the file [wikitext.yaml](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/lm_eval/tasks/wikitext/wikitext.yaml) we write:
   259	
   260	```yaml
   261	doc_to_target: !function preprocess_wikitext.wikitext_detokenizer
   262	```
   263	
   264	### Importing a Prompt from Promptsource
   265	
   266	[Promptsource](https://github.com/bigscience-workshop/promptsource/tree/main/promptsource) is a great repository for crowdsourced prompts for many datasets. We can load these prompts easily by using the `use_prompt` argument and filling it with the format `"promptsource:<name of prompt template>"`. To use this, `doc_to_text` and `doc_to_target` should be left undefined. This will fetch the template of the dataset defined in the YAML file.
   267	
   268	For example, For Super Glue BoolQ, if we want to use the prompt template `GPT-3 Style` we can add this to the YAML file.
   269	
   270	```yaml
   271	use_prompt: "promptsource:GPT-3 Style"
   272	```
   273	
   274	If you would like to run evaluation on all prompt templates, you can simply call it this way.
   275	
   276	```yaml
   277	use_prompt: "promptsource:*"
   278	```
   279	
   280	### Setting metrics
   281	
   282	You're almost done! Now we need to choose how to score our task.
   283	
   284	- *If this is a multiple choice task:* do you just want to check your model's accuracy in choosing the correct answer choice?
   285	- *If this is a generation task:* do you just want to check how often your model outputs *exactly the ground-truth output string provided*?
   286	
   287	If the answer to the above is no: you'll need to record what scoring metrics to use! Metrics can be listed in the following format:
   288	
   289	```yaml
   290	metric_list:
   291	  - metric: <name of the metric here>
   292	    aggregation: <name of the aggregation fn here>
   293	    higher_is_better: <true or false>
   294	  - metric: !function script.function
   295	    aggregation: ...
   296	    higher_is_better: ...
   297	```
   298	
   299	`aggregation` and `higher_is_better` can optionally be left out to default to the manually-set defaults if using a natively supported metric, otherwise it must be defined explicitly (for example, when using a custom metric implemented as a function).
   300	
   301	For a full list of natively supported metrics and aggregation functions see [`docs/task_guide.md`](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/docs/task_guide.md). All metrics supported in [HuggingFace Evaluate](https://github.com/huggingface/evaluate/tree/main/metrics) can also be used, and will be loaded if a given metric name is not one natively supported in `lm-eval` or `hf_evaluate` is set to `true`.
   302	
   303	### Optional, More Advanced Setup
   304	
   305	Some tasks may require more advanced processing logic than is described in this guide.
   306	
   307	As a heuristic check:
   308	
   309	- Does your task require generating multiple free-form outputs per input document?
   310	- Does your task require complex, multi-step post-processing of generated model outputs?
   311	- Does your task require subsetting documents on the fly based on their content?
   312	- Do you expect to compute metrics after applying multiple such processing steps on your model outputs?
   313	- Does your task rely on metrics that need a custom implementation?
   314	
   315	For more detail on the task system and advanced features, see [`docs/task_guide.md`](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/docs/task_guide.md). If none of the above sounds like they apply to your task, it's time to continue onto checking your task performance!
   316	
   317	### Task name + tags (registering a task)
   318	
   319	To test a task conveniently, it helps to *register* the task--that is, to give it a name and make the `lm-eval` library aware it exists!
   320	
   321	If you're writing your YAML file inside the `lm_eval/tasks` folder, you just need to give your task a name! You can do this inside your YAML file:
   322	
   323	```yaml
   324	task: <name of the task>
   325	```
   326	
   327	Including a task name is mandatory.
   328	
   329	It is often also convenient to label your task with several `tag` values, though this field is optional:
   330	
   331	```yaml
   332	tag:
   333	  - tag1
   334	  - tag2
   335	```
   336	
   337	This will add your task to the `tag1` and `tag2` tags, enabling people to know how to categorize your task, and if desired run all tasks in one of these groups at once, your task along with them.
   338	
   339	If your task is not in the `lm_eval/tasks` folder, you'll need to tell the Eval Harness where to look for YAML files.
   340	
   341	You can do this via the `--include_path` argument in `__main__.py`. This command will be used to initialize the `TaskManager` object which you can also use for your custom scripts.
   342	
   343	```python
   344	task_manager = TaskManager(args.verbosity, include_path=args.include_path)
   345	```
   346	
   347	Passing `--tasks /path/to/yaml/file` is also accepted.
   348	
   349	### Advanced Group Configs
   350
```

---

## LLM Step Analysis

**Strategy Shift:** no
- Reason: The agent continues reviewing the new task guide, focusing on details relevant to multiple-choice task configuration; this is a direct continuation of the prior documentation review.

**Command Impact:**
- Type: just explore
- Assessment: useful
- Reason: Reading the section on multiple choice format and metrics provides specific guidance for setting doc_to_text, doc_to_target, doc_to_choice, target_delimiter, and metric_list—information directly needed to implement the ESCI task.

**State Understanding:** yes
- Reason: The command successfully displayed the file contents and the agent correctly indicated it read the documentation; the output aligns with the action.

**Stage Label:** documentation deep dive (multiple-choice configuration)


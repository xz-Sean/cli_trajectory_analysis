# Step 152 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash

cat <<EOT > process_data.py
import pandas as pd

df_examples = pd.read_parquet('/app/esci-data/shopping_queries_dataset/shopping_queries_dataset_examples.parquet')

# Filter for ES locale and test split
es_test_df = df_examples[(df_examples['product_locale'] == 'es') & (df_examples['split'] == 'test')]

# Select the required columns
es_test_df = es_test_df[['query', 'esci_label', 'product_locale', 'product_id']]

# Save to jsonl
es_test_df.to_json('/app/esci.jsonl', orient='records', lines=True)

print(f"Number of examples in esci.jsonl: {len(es_test_df)}")
EOT

```

## Agent's Analysis

I will create the `esci.jsonl` file without the `product_title` column, as it is not available.

## Terminal Output

```
cat <<EOT > process_data.py
import pandas as pd
df_examples = pd.read_parquet('/app/esci-data/shopping_queries_dataset/shopping_queries_dataset_examples.parquet')
# Filter for ES locale and test split
es_test_df = df_examples[(df_examples['product_locale'] == 'es') & (df_examples['split'] == 'test')]
# Select the required columns
es_test_df = es_test_df[['query', 'esci_label', 'product_locale', 'product_id']]
# Save to jsonl
es_test_df.to_json('/app/esci.jsonl', orient='records', lines=True)
print(f"Number of examples in esci.jsonl: {len(es_test_df)}")
EOT > process_data.py
import pandas as pd
df_examples = pd.read_parquet('/app/esci-data/shopping_queries_dataset/shopping_queries_dataset_examples.parquet')
# Filter for ES locale and test split
es_test_df = df_examples[(df_examples['product_locale'] == 'es') & (df_examples['split'] == 'test')]
# Select the required columns
es_test_df = es_test_df[['query', 'esci_label', 'product_locale', 'product_id']]
# Save to jsonl
es_test_df.to_json('/app/esci.jsonl', orient='records', lines=True)
print(f"Number of examples in esci.jsonl: {len(es_test_df)}")
EOT
```

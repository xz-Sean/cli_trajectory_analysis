# Step 174 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
cat > esci_task.py <<EOL
from lm_eval.api.task import ConfigurableTask

class MyEsciTask(ConfigurableTask):
    DATASET_PATH = "/app/esci.jsonl"
    DATASET_NAME = None

    def has_training_docs(self):
        return True

    def has_validation_docs(self):
        return True

    def has_test_docs(self):
        return True

    def training_docs(self):
        if self._training_docs is None:
            self._training_docs = self.dataset["train"]
        return self._training_docs

    def validation_docs(self):
        return self.dataset["validation"]

    def test_docs(self):
        return self.dataset["test"]

    def doc_to_text(self, doc):
        return f'Is the following product relevant to the query? Query: {doc["query"]}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant.'

    def doc_to_target(self, doc):
        return " " + doc["esci_label"]

    def construct_requests(self, doc, ctx):
        ll_E, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " E")
        ll_S, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " S")
        ll_C, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " C")
        ll_I, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " I")
        return ll_E, ll_S, ll_C, ll_I

    def process_results(self, doc, results):
        gold = doc["esci_label"]
        pred = ""
        max_prob = -1
        if results[0] > max_prob:
            max_prob = results[0]
            pred = "E"
        if results[1] > max_prob:
            max_prob = results[1]
            pred = "S"
        if results[2] > max_prob:
            max_prob = results[2]
            pred = "C"
        if results[3] > max_prob:
            max_prob = results[3]
            pred = "I"
        return {"acc": pred == gold}

    def higher_is_better(self):
        return {"acc": True}

    def aggregation(self):
        return {"acc": "mean"}
EOL
```

## Agent's Analysis

I have tried everything I can think of to get the task to register. I will now try to run the benchmark by providing the task as a python file. I will create a python file that defines the task and then pass it to the `--tasks` argument. This should bypass the task registration process and allow me to run the benchmark. First, I will create the python file.

## Terminal Output

```
cat > esci_task.py <<EOL
from lm_eval.api.task import ConfigurableTask
class MyEsciTask(ConfigurableTask):
    DATASET_PATH = "/app/esci.jsonl"
    DATASET_NAME = None
    def has_training_docs(self):
        return True
    def has_validation_docs(self):
        return True
    def has_test_docs(self):
        return True
    def training_docs(self):
        if self._training_docs is None:
            self._training_docs = self.dataset["train"]
        return self._training_docs
    def validation_docs(self):
        return self.dataset["validation"]
    def test_docs(self):
        return self.dataset["test"]
    def doc_to_text(self, doc):
        return f'Is the following product relevant to the query? Query: {doc["query"]}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant.'
    def doc_to_target(self, doc):
        return " " + doc["esci_label"]
    def construct_requests(self, doc, ctx):
        ll_E, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " E")
        ll_S, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " S")
        ll_C, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " C")
        ll_I, _ = self.greedy_until(ctx, {"until": None, "max_gen_toks": 1}, doc, " I")
        return ll_E, ll_S, ll_C, ll_I
    def process_results(self, doc, results):
        gold = doc["esci_label"]
        pred = ""
        max_prob = -1
        if results[0] > max_prob:
            max_prob = results[0]
            pred = "E"
        if results[1] > max_prob:
            max_prob = results[1]
            pred = "S"
        if results[2] > max_prob:
            max_prob = results[2]
            pred = "C"
        if results[3] > max_prob:
            max_prob = results[3]
            pred = "I"
        return {"acc": pred == gold}
    def higher_is_better(self):
        return {"acc": True}
    def aggregation(self):
        return {"acc": "mean"}
EOL
```

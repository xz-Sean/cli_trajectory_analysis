# Step 105 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
myenv/bin/lm_eval --tasks list
```

## Agent's Analysis

Now I will run the `lm_eval --tasks list` command again.

## Terminal Output

```
|longbench_e                                     |
|longcxt                                         |
|m_mmlu                                          |
|mafand_afr-eng                                  |
|mafand_afr-eng_prompt_1                         |
|mafand_afr-eng_prompt_3                         |
|mafand_eng-afr                                  |
|mafand_eng-afr_prompt_1                         |
|mafand_eng-afr_prompt_2                         |
|mafand_eng-afr_prompt_3                         |
|mafand_tasks                                    |
|masakhaner_prompt_1                             |
|masakhaner_prompt_2                             |
|masakhaner_prompt_3                             |
|masakhaner_prompt_4                             |
|masakhaner_prompt_5                             |
|masakhaner_tasks                                |
|masakhanews_prompt_1                            |
|masakhanews_prompt_2                            |
|masakhanews_prompt_3                            |
|masakhanews_prompt_4                            |
|masakhanews_prompt_5                            |
|masakhanews_tasks                               |
|masakhapos_prompt_1                             |
|masakhapos_prompt_2                             |
|masakhapos_prompt_3                             |
|masakhapos_prompt_4                             |
|masakhapos_prompt_5                             |
|masakhapos_tasks                                |
|mastermind                                      |
|mastermind_easy                                 |
|mastermind_hard                                 |
|math_word_problems                              |
|med_concepts_qa_atc_tasks                       |
|med_concepts_qa_icd10cm_tasks                   |
|med_concepts_qa_icd10proc_tasks                 |
|med_concepts_qa_icd9cm_tasks                    |
|med_concepts_qa_icd9proc_tasks                  |
|metabench_arc_subset                            |
|metabench_gsm8k_subset                          |
|metabench_hellaswag_subset                      |
|metabench_mmlu_subset                           |
|metabench_truthfulqa_subset                     |
|metabench_winogrande_subset                     |
|mgsm_cot_native                                 |
|mgsm_direct                                     |
|mmlu_cot_llama_humanities_tasks                 |
|mmlu_cot_llama_other_tasks                      |
|mmlu_cot_llama_social_sciences_tasks            |
|mmlu_cot_llama_stem_tasks                       |
|mmlu_de_llama_humanities_tasks                  |
|mmlu_de_llama_other_tasks                       |
|mmlu_de_llama_social_sciences_tasks             |
|mmlu_de_llama_stem_tasks                        |
|mmlu_es_llama_humanities_tasks                  |
|mmlu_es_llama_other_tasks                       |
|mmlu_es_llama_social_sciences_tasks             |
|mmlu_es_llama_stem_tasks                        |
|mmlu_flan_cot_fewshot_humanities                |
|mmlu_flan_cot_fewshot_other                     |
|mmlu_flan_cot_fewshot_social_sciences           |
|mmlu_flan_cot_fewshot_stem                      |
|mmlu_flan_cot_zeroshot_humanities               |
|mmlu_flan_cot_zeroshot_other                    |
|mmlu_flan_cot_zeroshot_social_sciences          |
|mmlu_flan_cot_zeroshot_stem                     |
|mmlu_flan_n_shot_generative_humanities          |
|mmlu_flan_n_shot_generative_other               |
|mmlu_flan_n_shot_generative_social_sciences     |
|mmlu_flan_n_shot_generative_stem                |
|mmlu_flan_n_shot_loglikelihood_humanities       |
|mmlu_flan_n_shot_loglikelihood_other            |
|mmlu_flan_n_shot_loglikelihood_social_sciences  |
|mmlu_flan_n_shot_loglikelihood_stem             |
|mmlu_fr_llama_humanities_tasks                  |
|mmlu_fr_llama_other_tasks                       |
|mmlu_fr_llama_social_sciences_tasks             |
|mmlu_fr_llama_stem_tasks                        |
|mmlu_hi_llama_humanities_tasks                  |
|mmlu_hi_llama_other_tasks                       |
|mmlu_hi_llama_social_sciences_tasks             |
|mmlu_hi_llama_stem_tasks                        |
|mmlu_humanities_continuation                    |
|mmlu_humanities_generative                      |
|mmlu_humanities_tasks                           |
|mmlu_it_llama_humanities_tasks                  |
|mmlu_it_llama_other_tasks                       |
|mmlu_it_llama_social_sciences_tasks             |
|mmlu_it_llama_stem_tasks                        |
|mmlu_llama_humanities_tasks                     |
|mmlu_llama_other_tasks                          |
|mmlu_llama_social_sciences_tasks                |
|mmlu_llama_stem_tasks                           |
|mmlu_other_continuation                         |
|mmlu_other_generative                           |
|mmlu_other_tasks                                |
|mmlu_pt_llama_humanities_tasks                  |
|mmlu_pt_llama_other_tasks                       |
|mmlu_pt_llama_social_sciences_tasks             |
|mmlu_pt_llama_stem_tasks                        |
|mmlu_social_sciences_continuation               |
|mmlu_social_sciences_generative                 |
|mmlu_social_sciences_tasks                      |
|mmlu_stem_continuation                          |
|mmlu_stem_generative                            |
|mmlu_stem_tasks                                 |
|mmlu_th_llama_humanities_tasks                  |
|mmlu_th_llama_other_tasks                       |
|mmlu_th_llama_social_sciences_tasks             |
|mmlu_th_llama_stem_tasks                        |
|mmlusr_answer_only_humanities_tasks             |
|mmlusr_answer_only_other_tasks                  |
|mmlusr_answer_only_social_sciences_tasks        |
|mmlusr_answer_only_stem_tasks                   |
|mmlusr_question_and_answer_humanities_tasks     |
|mmlusr_question_and_answer_other_tasks          |
|mmlusr_question_and_answer_social_sciences_tasks|
|mmlusr_question_and_answer_stem_tasks           |
|mmlusr_question_only_humanities_tasks           |
|mmlusr_question_only_other_tasks                |
|mmlusr_question_only_social_sciences_tasks      |
|mmlusr_question_only_stem_tasks                 |
|multiblimp                                      |
|multiple_choice                                 |
|naijarc_prompt_1                                |
|naijarc_prompt_2                                |
|naijarc_prompt_3                                |
|naijarc_prompt_4                                |
|naijarc_prompt_5                                |
|naijarc_tasks                                   |
|nollysenti_prompt_1                             |
|nollysenti_prompt_2                             |
|nollysenti_prompt_3                             |
|nollysenti_prompt_4                             |
|nollysenti_prompt_5                             |
|norbelebele                                     |
|norcommonsenseqa_nno                            |
|norcommonsenseqa_nob                            |
|norec_document                                  |
|norec_sentence                                  |
|noridiom_nno                                    |
|noridiom_nob                                    |
|noropenbookqa_nno                               |
|noropenbookqa_nob                               |
|norquad                                         |
|norsumm_nno                                     |
|norsumm_nob                                     |
|nortruthfulqa_gen_nno                           |
|nortruthfulqa_gen_nob                           |
|nortruthfulqa_mc_nno                            |
|nortruthfulqa_mc_nob                            |
|nrk_quiz_qa_nno                                 |
|nrk_quiz_qa_nob                                 |
|ntrex_afr-eng                                   |
|ntrex_afr-eng_prompt_1                          |
|ntrex_afr-eng_prompt_2                          |
|ntrex_afr-eng_prompt_3                          |
|ntrex_eng-afr                                   |
|ntrex_eng-afr_prompt_1                          |
|ntrex_eng-afr_prompt_2                          |
|ntrex_eng-afr_prompt_3                          |
|ntrex_tasks                                     |
|openai_mmlu_prompt_1                            |
|openai_mmlu_prompt_2                            |
|openai_mmlu_prompt_3                            |
|openai_mmlu_prompt_4                            |
|openai_mmlu_prompt_5                            |
|openai_mmlu_tasks                               |
|paloma                                          |
|persona                                         |
|phrases_es                                      |
|phrases_va                                      |
|polemo2                                         |
|qa4mre                                          |
|qasper                                          |
|salt_prompt_1                                   |
|salt_prompt_2                                   |
|salt_prompt_3                                   |
|salt_tasks                                      |
|score_robustness_mmlu_pro                       |
|self_consistency                                |
|sib_prompt_1                                    |
|sib_prompt_2                                    |
|sib_prompt_3                                    |
|sib_prompt_4                                    |
|sib_prompt_5                                    |
|sib_tasks                                       |
|social_bias                                     |
|storycloze                                      |
|super-glue-lm-eval-v1                           |
|super-glue-lm-eval-v1-seq2seq                   |
|super-glue-t5-prompt                            |
|sycophancy                                      |
|tatoeba_eng_nno                                 |
|tatoeba_eng_nob                                 |
|tatoeba_nno_eng                                 |
|tatoeba_nob_eng                                 |
|tmlu_humanities_tasks                           |
|tmlu_other_tasks                                |
|tmlu_social_sciences_tasks                      |
|tmlu_stem_tasks                                 |
|tmlu_taiwan_specific_tasks                      |
|tmmluplus_STEM_tasks                            |
|tmmluplus_humanities_tasks                      |
|tmmluplus_other_tasks                           |
|tmmluplus_social_sciences_tasks                 |
|translation                                     |
|truthfulqa                                      |
|truthfulqa-multi                                |
|truthfulqa_gl                                   |
|truthfulqa_multi                                |
|truthfulqa_multilingual                         |
|turkishmmlu                                     |
|turkishmmlu_cot                                 |
|uhura_arc_easy_prompt_1                         |
|uhura_arc_easy_prompt_2                         |
|uhura_arc_easy_prompt_3                         |
|uhura_arc_easy_prompt_4                         |
|uhura_arc_easy_prompt_5                         |
|uhura_arc_easy_tasks                            |
|unscramble                                      |
|winogender                                      |
|wmt14                                           |
|wmt16                                           |
|xlsum_prompt_1                                  |
|xlsum_prompt_2                                  |
|xlsum_prompt_3                                  |
|xlsum_tasks                                     |
|xnli_eu_mt_native                               |
|xquad                                           |


|                                         Task                                         |                                                                        Config Location                                                                         |     Output Type     |
|--------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
|20_newsgroups                                                                         |lm_eval/tasks/unitxt/20_newsgroups.yaml                                                                                                                         |                     |
|AraDiCE_ArabicMMLU_high_humanities_history_egy                                        |lm_eval/tasks/aradice/ArabicMMLU/EGY/AraDiCE_ArabicMMLU_high_humanities_history.yaml                                                                            |multiple_choice      |
|AraDiCE_ArabicMMLU_high_humanities_history_lev                                        |lm_eval/tasks/aradice/ArabicMMLU/LEV/AraDiCE_ArabicMMLU_high_humanities_history.yaml                                                                            |multiple_choice      |
|AraDiCE_ArabicMMLU_high_humanities_islamic-studies_egy                                |lm_eval/tasks/aradice/ArabicMMLU/EGY/AraDiCE_ArabicMMLU_high_humanities_islamic-studies.yaml                                                                    |multiple_choice      |
|AraDiCE_ArabicMMLU_high_humanities_islamic-studies_lev                                |lm_eval/tasks/aradice/ArabicMMLU/LEV/AraDiCE_ArabicMMLU_high_humanities_islamic-studies.yaml                                                                    |multiple_choice      |
|AraDiCE_ArabicMMLU_high_humanities_philosophy_egy                                     |lm_eval/tasks/aradice/ArabicMMLU/EGY/AraDiCE_ArabicMMLU_high_humanities_philosophy.yaml                                                                         |multiple_choice      |
|AraDiCE_ArabicMMLU_high_humanities_philosophy_lev                                     |lm_eval/tasks/aradice/ArabicMMLU/LEV/AraDiCE_ArabicMMLU_high_humanities_philosophy.yaml                                                                         |multiple_choice      |
|AraDiCE_ArabicMMLU_high_language_arabic-language_egy                                  |lm_eval/tasks/aradice/ArabicMMLU/EGY/AraDiCE_ArabicMMLU_high_language_arabic-language.yaml                                                                      |multiple_choice      |
|AraDiCE_ArabicMMLU_high_language_arabic-language_lev                                  |lm_eval/tasks/aradice/ArabicMMLU/LEV/AraDiCE_ArabicMMLU_high_language_arabic-language.yaml                                                                      |multiple_choice      |
|AraDiCE_ArabicMMLU_high_social-science_civics_egy                                     |lm_eval/tasks/aradice/ArabicMMLU/EGY/AraDiCE_ArabicMMLU_high_social-science_civics.yaml                                                                         |multiple_choice      |
|Ara
[... Observation truncated due to length ...]
                 |generate_until       |
|xnli_ar                                                                               |lm_eval/tasks/xnli/xnli_ar.yaml                                                                                                                                 |multiple_choice      |
|xnli_bg                                                                               |lm_eval/tasks/xnli/xnli_bg.yaml                                                                                                                                 |multiple_choice      |
|xnli_ca                                                                               |lm_eval/tasks/catalan_bench/xnli_ca.yaml                                                                                                                        |multiple_choice      |
|xnli_de                                                                               |lm_eval/tasks/xnli/xnli_de.yaml                                                                                                                                 |multiple_choice      |
|xnli_el                                                                               |lm_eval/tasks/xnli/xnli_el.yaml                                                                                                                                 |multiple_choice      |
|xnli_en                                                                               |lm_eval/tasks/xnli/xnli_en.yaml                                                                                                                                 |multiple_choice      |
|xnli_es                                                                               |lm_eval/tasks/xnli/xnli_es.yaml                                                                                                                                 |multiple_choice      |
|xnli_es_spanish_bench                                                                 |lm_eval/tasks/spanish_bench/xnli_es_spanish_bench.yaml                                                                                                          |multiple_choice      |
|xnli_eu                                                                               |lm_eval/tasks/xnli_eu/xnli_eu.yaml                                                                                                                              |multiple_choice      |
|xnli_eu_mt                                                                            |lm_eval/tasks/xnli_eu/xnli_eu_mt.yaml                                                                                                                           |multiple_choice      |
|xnli_eu_native                                                                        |lm_eval/tasks/xnli_eu/xnli_eu_native.yaml                                                                                                                       |multiple_choice      |
|xnli_fr                                                                               |lm_eval/tasks/xnli/xnli_fr.yaml                                                                                                                                 |multiple_choice      |
|xnli_gl                                                                               |lm_eval/tasks/galician_bench/xnli_gl.yaml                                                                                                                       |multiple_choice      |
|xnli_hi                                                                               |lm_eval/tasks/xnli/xnli_hi.yaml                                                                                                                                 |multiple_choice      |
|xnli_ru                                                                               |lm_eval/tasks/xnli/xnli_ru.yaml                                                                                                                                 |multiple_choice      |
|xnli_sw                                                                               |lm_eval/tasks/xnli/xnli_sw.yaml                                                                                                                                 |multiple_choice      |
|xnli_th                                                                               |lm_eval/tasks/xnli/xnli_th.yaml                                                                                                                                 |multiple_choice      |
|xnli_tr                                                                               |lm_eval/tasks/xnli/xnli_tr.yaml                                                                                                                                 |multiple_choice      |
|xnli_ur                                                                               |lm_eval/tasks/xnli/xnli_ur.yaml                                                                                                                                 |multiple_choice      |
|xnli_vi                                                                               |lm_eval/tasks/xnli/xnli_vi.yaml                                                                                                                                 |multiple_choice      |
|xnli_zh                                                                               |lm_eval/tasks/xnli/xnli_zh.yaml                                                                                                                                 |multiple_choice      |
|xquad_ar                                                                              |lm_eval/tasks/xquad/xquad_ar.yaml                                                                                                                               |generate_until       |
|xquad_ca                                                                              |lm_eval/tasks/catalan_bench/xquad_ca.yaml                                                                                                                       |generate_until       |
|xquad_de                                                                              |lm_eval/tasks/xquad/xquad_de.yaml                                                                                                                               |generate_until       |
|xquad_el                                                                              |lm_eval/tasks/xquad/xquad_el.yaml                                                                                                                               |generate_until       |
|xquad_en                                                                              |lm_eval/tasks/xquad/xquad_en.yaml                                                                                                                               |generate_until       |
|xquad_es                                                                              |lm_eval/tasks/xquad/xquad_es.yaml                                                                                                                               |generate_until       |
|xquad_hi                                                                              |lm_eval/tasks/xquad/xquad_hi.yaml                                                                                                                               |generate_until       |
|xquad_ro                                                                              |lm_eval/tasks/xquad/xquad_ro.yaml                                                                                                                               |generate_until       |
|xquad_ru                                                                              |lm_eval/tasks/xquad/xquad_ru.yaml                                                                                                                               |generate_until       |
|xquad_th                                                                              |lm_eval/tasks/xquad/xquad_th.yaml                                                                                                                               |generate_until       |
|xquad_tr                                                                              |lm_eval/tasks/xquad/xquad_tr.yaml                                                                                                                               |generate_until       |
|xquad_vi                                                                              |lm_eval/tasks/xquad/xquad_vi.yaml                                                                                                                               |generate_until       |
|xquad_zh                                                                              |lm_eval/tasks/xquad/xquad_zh.yaml                                                                                                                               |generate_until       |
|xstorycloze_ar                                                                        |lm_eval/tasks/xstorycloze/default_ar.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_ca                                                                        |lm_eval/tasks/catalan_bench/xstorycloze_ca.yaml                                                                                                                 |multiple_choice      |
|xstorycloze_en                                                                        |lm_eval/tasks/xstorycloze/default_en.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_es                                                                        |lm_eval/tasks/xstorycloze/default_es.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_eu                                                                        |lm_eval/tasks/xstorycloze/default_eu.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_gl                                                                        |lm_eval/tasks/galician_bench/xstorycloze_gl.yaml                                                                                                                |multiple_choice      |
|xstorycloze_hi                                                                        |lm_eval/tasks/xstorycloze/default_hi.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_id                                                                        |lm_eval/tasks/xstorycloze/default_id.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_my                                                                        |lm_eval/tasks/xstorycloze/default_my.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_ru                                                                        |lm_eval/tasks/xstorycloze/default_ru.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_sw                                                                        |lm_eval/tasks/xstorycloze/default_sw.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_te                                                                        |lm_eval/tasks/xstorycloze/default_te.yaml                                                                                                                       |multiple_choice      |
|xstorycloze_zh                                                                        |lm_eval/tasks/xstorycloze/default_zh.yaml                                                                                                                       |multiple_choice      |
|xsum                                                                                  |lm_eval/tasks/unitxt/xsum.yaml                                                                                                                                  |                     |
|xwinograd_en                                                                          |lm_eval/tasks/xwinograd/xwinograd_en.yaml                                                                                                                       |multiple_choice      |
|xwinograd_fr                                                                          |lm_eval/tasks/xwinograd/xwinograd_fr.yaml                                                                                                                       |multiple_choice      |
|xwinograd_jp                                                                          |lm_eval/tasks/xwinograd/xwinograd_jp.yaml                                                                                                                       |multiple_choice      |
|xwinograd_pt                                                                          |lm_eval/tasks/xwinograd/xwinograd_pt.yaml                                                                                                                       |multiple_choice      |
|xwinograd_ru                                                                          |lm_eval/tasks/xwinograd/xwinograd_ru.yaml                                                                                                                       |multiple_choice      |
|xwinograd_zh                                                                          |lm_eval/tasks/xwinograd/xwinograd_zh.yaml                                                                                                                       |multiple_choice      |
|yahoo_answers_topics                                                                  |lm_eval/tasks/unitxt/yahoo_answers_topics.yaml                                                                                                                  |                     |
```

# Step 128 Analysis

**Task:** add-benchmark-lm-eval-harness

---

## Command

```bash
echo 'task: esci' > lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'group:' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo '  - esci' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'dataset_path: /app/esci.jsonl' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'output_type: multiple_choice' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'training_split: train' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'validation_split: test' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'test_split: test' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'doc_to_text: "Is the following product relevant to the query? Query: {{query}}. Respond with one of the following characters: E for Exact, C for Complement, S for Substitute, or I for Irrelevant.'" >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'doc_to_choice: ["E", "S", "C", "I"]' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'doc_to_target: esci_label' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo 'metric_list:' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo '  - metric: acc' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo '    aggregation: mean' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml && \
echo '    higher_is_better: true' >> lm-evaluation-harness/lm_eval/tasks/esci.yaml
```

## Agent's Analysis



## Terminal Output

```

```

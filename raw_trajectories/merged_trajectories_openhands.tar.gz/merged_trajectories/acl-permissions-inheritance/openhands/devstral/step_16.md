# Step 16 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
getfacl /srv/shared/test_subdir
```

## Agent's Analysis



## Terminal Output

```
getfacl: Removing leading '/' from absolute path names
# file: srv/shared/test_subdir
# owner: root
# group: research
# flags: -s-
user::rwx
user:alice:rwx
user:bob:rwx
group::rwx
mask::rwx
other::---
default:user::rwx
default:user:alice:rwx
default:user:bob:rwx
default:group::rwx
default:mask::rwx
default:other::---
```

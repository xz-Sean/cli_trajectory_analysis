# Step 22 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
su -s /bin/bash -c "ls /srv/shared 2>&1" nobody
```

## Agent's Analysis

Perfect! Let me also test that users outside the research group cannot access the directory:

## Terminal Output

```
ls: cannot open directory '/srv/shared': Permission denied
```

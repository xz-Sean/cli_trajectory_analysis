# Step 8 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
setfacl -R -m u::rwx,g::rwx,o::---,m::rwx /srv/shared
```

## Agent's Analysis

Now I'll configure the ACLs as specified. I need to set both current and default ACLs to ensure proper inheritance.

## Terminal Output

```

```

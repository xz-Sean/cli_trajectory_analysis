# Step 17 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
getfacl /srv/shared/test_file.txt
```

## Agent's Analysis



## Terminal Output

```
getfacl: Removing leading '/' from absolute path names
# file: srv/shared/test_file.txt
# owner: root
# group: research
user::rw-
user:alice:rwx                  #effective:rw-
user:bob:rwx                    #effective:rw-
group::rwx                      #effective:rw-
mask::rw-
other::---
```

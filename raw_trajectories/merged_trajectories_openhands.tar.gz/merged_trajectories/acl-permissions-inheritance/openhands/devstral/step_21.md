# Step 21 Analysis

**Task:** acl-permissions-inheritance

---

## Command

```bash
ls -ld /srv/shared
```

## Agent's Analysis



## Terminal Output

```
drwxrws---+ 2 root research 4096 Apr 14 14:34 /srv/shared
```
